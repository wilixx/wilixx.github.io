# CARELab Carbon Studio / 碳感知工作流演示

A browser-only 3D comparison of six real DAG schedulers, explicit shared-channel transfers, and exact operational-carbon accounting. / 在浏览器中运行六种真实 DAG 调度算法，以 3D 动画、共享网络通道和精确积分展示运行碳排放。

Online demo / 在线演示: <https://wilixx.github.io/demos/llm-carbon-studio/>.

## Run and build / 启动与构建

Use Node.js **22.12 or later** and pnpm. / 使用 **Node.js 22.12 或更新版本**及 pnpm。

```sh
pnpm install --frozen-lockfile
pnpm dev
# http://127.0.0.1:5190
pnpm test
pnpm build
pnpm preview
```

`pnpm build` creates `dist/`, a static site with relative asset URLs. Deploy its contents to an HTTP(S) host, retaining asset and source/notice files. Opening `dist/index.html` with `file://` is unsupported because module workers require an HTTP(S) origin. / `dist/` 是静态网站，资源路径为相对路径；部署时保留资源及源码、许可文件。模块 Worker 需要 HTTP(S) 来源，不支持直接双击 `file://` 文件。

The application needs no backend. Imported files and scheduling data stay in the browser. GLPK executes in a worker; stopping the solver terminates that worker. / 无需后端。导入文件与调度数据在浏览器内处理；GLPK 在 Worker 中执行，停止按钮终止求解 Worker。

## Recording and presentation / 录制与展示

The top-left Home control returns to the academic homepage. Sidebar contacts reuse the verified IEEE, Google Scholar, GitHub, email, WeChat QR and LinkedIn links. The compact comparison heading and synchronized bottom scrollbar keep horizontal navigation available without scrolling down. / 左上角可返回主页；侧栏提供学术主页与联系方式。比较区标题已压缩，底部常驻横向滚动条与方法面板同步。

Choose **Record → Start recording**, then select the current tab in the browser's screen-sharing dialog. Capture includes the entire visible interface, not content outside the current viewport. Pause/resume controls recording only; the simulation has its own playback controls. Stop, preview, then **Save MP4**. / 点击“录屏 → 开始录制”，在浏览器窗口中选择当前标签页。录制整个可见界面，不包含屏幕之外的网页内容。录屏暂停与仿真播放独立；结束后预览并保存 MP4。

A supporting desktop browser records MP4 directly. Other supported browsers record WebM and convert it locally to actual MP4 using Mediabunny 1.59.1 / WebCodecs. Failed conversion preserves the original clip and offers retry; files are never renamed to masquerade as MP4. There is no audio capture or upload. Each clip is limited to 10 minutes or 200 MB to bound memory use. Browser sharing consent is required for each recording; screen capture is not assumed to work while the operating system is locked. / 优先原生 MP4，否则在本机实际转换。转换失败保留原始片段，可重试，不冒用扩展名。无声音采集、无上传，单段限 10 分钟或 200 MB。每次录制都需浏览器授权选择画面，不假设锁屏时能够录制。

Validation: 53 Node tests (39 scheduling/accounting + 14 recording) pass. Real browser canvas-stream tests produced playable native MP4 and VP8-WebM-to-MP4 output, verified container bytes, pause exclusion, video dimensions and track release. Local `qa/` fixtures are excluded from production builds. / 53 项测试通过，并通过真实浏览器验证原生录制与转换后的 MP4 可播放、暂停时间不计入、尺寸正确、捕获轨道释放；QA 页面不发布。

## Carbon model / 碳核算模型

Let `T` and each compute duration `pᵢ` be measured in time units (tu), `s = tuSeconds` be seconds/tu, `K` be the fixed reserved VM count, and `f = PUE × CI / 3,600,000`. Powers are watts; `CI` is gCO₂e/kWh. / `T` 与计算时长 `pᵢ` 的单位为 tu；`s` 为每 tu 的秒数，`K` 为固定预留 VM 数量；功率单位为 W，碳强度为 gCO₂e/kWh。

```text
A = f × s × Σᵢ pᵢ × (Pbusy − Pidle)                  [gCO₂e]
B = f × s × (K × Pidle + Pnetwork)                  [gCO₂e / tu]
C(T) = A + B × T                                   [gCO₂e]

Ehost,k(t) = Pidle × τs + (Pbusy − Pidle) × busy_seconds,k(τ)
Enetwork(t) = Pnetwork × τs
τ = clamp(t, 0, T)
C(t) = f × [Σk Ehost,k(t) + Enetwork(t)]
```

All `K` VMs remain reserved until the **whole job** completes, including VMs with no assigned tasks. `Pbusy` is total busy power, so only `Pbusy − Pidle` is added to the baseline. Network power is a constant reservation baseline independent of traffic and channel count. Transfer plumes visualize activity and do not add a second energy charge. / 所有 VM（包括未分配任务的 VM）均预留至整个作业结束。计算功率是总功率，增量仅为忙碌功率减空闲功率。网络基础功率不随流量或通道数重复增加；传输烟雾只表示活动。

At completion, the job ledger freezes and attributed instantaneous power becomes zero. Half-open busy intervals are integrated analytically, including fractional boundaries; playback speed and step size cannot change final carbon. / 作业结束后累计值保持不变，归属于该作业的瞬时功率归零。忙闲区间采用半开区间并精确积分，播放速度、步长不影响最终碳排放。

The equivalence between minimizing `C` and `T` assumes identical fixed task profiles, VM count, CI, PUE, idle baseline, and traffic-independent network allocation across methods, with `B > 0`. If `B = 0`, carbon can tie despite different completion times. This is a synthetic operational-electricity allocation model; embodied emissions and solver energy are excluded. / 同一任务执行配置、VM 数量、CI、PUE 与预留基础功率固定，且 `B > 0` 时，碳最小与完成时间最短的排序一致。`B = 0` 时可能不同完成时间对应相同碳排放。此合成运行电力模型不含硬件制造碳和求解算法能耗。

## Methods and certificates / 算法与证明

| ID | Method / 方法 | Behavior / 行为 |
|---|---|---|
| `list` | List scheduling / 列表调度 | Compute-rank priority; placement estimates transfer latency, then allocates actual shared channels. / 计算优先级，放置阶段估计通信时延，再安排真实通道。 |
| `random` | Seeded random / 种子随机 | Reproducible random ready-task and host choices. / 可复现的就绪任务及主机随机选择。 |
| `aware` | Network-aware list / 通信感知列表 | Evaluates every host with explicit channel calendars. / 联合评估主机与共享通道日历。 |
| `reserve` | CARE Reserve search / CARE 预留搜索 | Best of deterministic/random seeds, then two passes of single-task relocation. / 多初始方案与两轮单任务重定位局部搜索。 |
| `serial` | Serial / 串行 | Places all tasks on VM 0; local dependencies transfer no data. / 全任务放置于 VM 0，本地依赖不占网络通道。 |
| `milp` | GLPK 5.0.0 MILP | Continuous start times, binary host assignment, exact cross-host activation, and server/channel disjunctions; minimizes `T`. / 连续开始时间、二元主机分配、精确传输激活及主机/通道互斥，最小化 `T`。 |

All returned schedules pass physical duration, precedence, assignment, and resource-mutex validation. Cross-host zero-duration edges remain explicit but occupy no channel capacity. / 所有返回方案均验证时长、前驱依赖、分配与资源互斥；跨主机零时长边仍保留，但不占通道容量。

Heuristics accept up to 32 tasks. MILP runs only up to **14 tasks and 35 edges**; larger inputs explicitly return a validated Reserve fallback. Its default **5-second** budget includes heuristic seeding and model construction; the remaining seconds are passed to GLPK with zero requested MIP gap. Solver initialization/download precedes the per-method timer. GLPK setup and message overhead can cause a small wall-time overrun. / 启发式最多支持 32 个任务。MILP 上限为 **14 个任务、35 条边**，超限明确回退。默认 **5 秒**预算包括初始可行解与模型构建，剩余时间交给 GLPK；求解器首次加载在算法计时之前，底层建模及消息开销可能造成少量墙钟时间超出。

`optimal` means GLPK proved optimality within numerical tolerances. `feasible` means a validated solver incumbent without proof. `fallback` means the reported schedule is the validated heuristic because of the size guard, unavailable solver, no incumbent, or failed output validation. Algorithm runtime is milliseconds of scheduling work, distinct from job completion in tu and playback duration. / `optimal` 为数值容差内证明最优；`feasible` 为已验证但未证明最优的求解器可行解；`fallback` 为明确标记的启发式回退。算法运行毫秒数与作业完成 tu、动画播放时长是不同指标。

No Lyapunov method is included. / 本版本不含李雅普诺夫方法。

## Reproducible example and tests / 可复现实例与测试

Defaults: `K=3`, channels `2`, `Pidle=70 W`, `Pbusy=320 W`, network `25 W`, PUE `1.2`, CI `400`, seconds/tu `1`, scheduling seed `12`. `demoDag()` has 8 tasks, 12 dependencies, and total compute work 42 tu; it uses the fixed fork/join graph generated with graph seed 70. Thus `A=1.4 g`, `B=0.0313333333 g/tu`. / 默认参数及固定图在所有方法间相同，图生成种子与调度种子分开。

| Method / 方法 | Completion / 完成时间 (tu) | Carbon / 碳排放 (gCO₂e) |
|---|---:|---:|
| List | 28 | 2.277333 |
| Random | 33 | 2.434000 |
| Network-aware | 27 | 2.246000 |
| CARE Reserve | 26 | 2.214667 |
| Serial | 42 | 2.716000 |
| GLPK MILP | 25 | 2.183333 |

These values were recomputed from the implementation; GLPK certified 25 tu in a local Node run (~2.8 s). Different devices may hit the time limit and return another valid status/result. / 上述值由实现重新计算，本地 Node 运行约 2.8 秒获得 25 tu 最优证明；其他设备可能触发限时并返回其他有效状态与结果。

`pnpm test`: **39 passing tests** at documentation time, covering all generators/heuristics, independent physical checks, fractional integration, conservation and affine identities, playback invariance, zero-time transfers, parallel channels, analytic small MILP optima, and honest fallback statuses. / 测试覆盖各生成器、启发式、物理约束、分数时间积分、能量守恒、仿射恒等式、播放无关性、零时长传输、并行通道、解析最优解与回退状态。

## Extension API / 扩展接口

`src/engine.js` exports `DEFAULTS`, `METHODS`, `demoDag()`, `generateDag(kind,count,seed)`, `normalizeInput(dag,config)`, `solveHeuristic(dag,method)`, `solveMilp(dag,config,glpk)`, `validateSchedule(dag,result)`, and `ledgerAt(dag,result,config,time)`.

```js
const dag = normalizeInput({
  nodes: [{ id: 0, duration: 2 }, { id: 1, duration: 3 }],
  edges: [{ source: 0, target: 1, duration: 0.5 }],
  resources: { servers: 2, channels: 1 }, seed: 12,
}, { servers: 2, channels: 1 });
const result = solveHeuristic(dag, 'aware');
validateSchedule(dag, result);
const atOneTu = ledgerAt(dag, result, { servers: 2, channels: 1 }, 1);
```

IDs and resource indices are numeric and zero-based; node IDs may be noncontiguous. Explicit config overrides raw resources and seed. A result contains `tasks:[{id,resource,start,end}]`, `flows:[{source,target,resource,start,end}]`, `completion_time`, `method`, `status`, and `runtime_ms`. / ID 与资源索引为数字、从零开始；任务 ID 可不连续。显式配置覆盖原始资源与种子。

Generator names: `pipeline`, `forkjoin`, `mapreduce`, `diamond`, `layered`, `random`, `tree`, `independent`. Worker input is `{id,dag,config,methods}`; output is `progress`, one `result` per method, then `done`, or `error`, always carrying `id`. Add schedulers through the engine, validate their output, and register their metadata in the UI. / Worker 按方法逐个返回结果，保留请求 ID；新增算法应复用验证器并注册 UI 元数据。

## Sources and notices / 源码与许可

Runtime dependency versions, full license texts, and upstream package/source URLs are in [`public/THIRD_PARTY_NOTICES.txt`](public/THIRD_PARTY_NOTICES.txt); Vite copies it to the deployed site root. / 运行依赖版本、完整许可与上游链接见该文件，构建时复制到站点根目录。

The installed glpk.js npm package contains compiled GLPK 5.0 and wrapper/build files but **omits `src/glpk`, its GNU GLPK source submodule**. The distribution includes [`glpk-5.0.0-source.zip`](./glpk-5.0.0-source.zip), containing pinned glpk.js commit `80e1ff5bd80b588bc233a4427b0687128146c8d0` and GNU GLPK submodule commit `4945cf1cb8e860b24d8b79a8a258c2d214945d10`, with build scripts and upstream lockfile. Rebuilding uses Emscripten 4.0.3 as pinned in the upstream Dockerfile. / 已补齐匹配版本的完整 GNU GLPK 子模块、构建脚本及锁文件；上游 Dockerfile 指定 Emscripten 4.0.3。

Application source distribution / 应用源码归档: [`carelab-carbon-studio-source.zip`](./carelab-carbon-studio-source.zip), prepared as part of the site release. Archive links are relative to the published site root. Preserve source archives and license notices with the deployed artifacts. / 该归档作为站点发布的一部分生成；链接相对于站点根目录，发布时保留源码归档与许可声明。
