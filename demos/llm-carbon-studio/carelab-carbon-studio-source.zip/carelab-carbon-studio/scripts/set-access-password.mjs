import { emitKeypressEvents } from 'node:readline';
import { writeFile, rename, rm } from 'node:fs/promises';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { createAccessConfig, PASSWORD_MAX_LENGTH } from '../src/access.js';

const defaultDestination = fileURLToPath(new URL('../src/access-config.js', import.meta.url));

export async function writeAccessConfiguration(password, destination = defaultDestination) {
  const config = await createAccessConfig(password);
  const output = '// Public salted verifier for a temporary demonstration gate. Not server authentication.\n' +
    `export const ACCESS_CONFIG = Object.freeze(${JSON.stringify(config, null, 2)});\n`;
  const temporary = `${destination}.${process.pid}.tmp`;
  let created = false;
  try {
    await writeFile(temporary, output, { encoding: 'utf8', flag: 'wx', mode: 0o600 });
    created = true;
    await rename(temporary, destination);
  } catch (error) {
    if (created) await rm(temporary, { force: true }).catch(() => {});
    throw error;
  }
  return config;
}

function readHidden(prompt) {
  return new Promise((resolveInput, reject) => {
    process.stdout.write(prompt);
    let value = '';
    const done = (error) => {
      process.stdin.off('keypress', keypress);
      process.stdin.setRawMode(false);
      process.stdin.pause();
      process.stdout.write('\n');
      if (error) reject(error); else resolveInput(value);
    };
    const keypress = (text, key = {}) => {
      if ((key.ctrl && key.name === 'c') || key.name === 'escape') return done(new Error('Cancelled.'));
      if (key.name === 'return' || key.name === 'enter') return done();
      if (key.name === 'backspace') { value = Array.from(value).slice(0, -1).join(''); return; }
      if (key.ctrl || key.meta || !text || /[\u0000-\u001f\u007f]/.test(text)) return;
      if (value.length + text.length > PASSWORD_MAX_LENGTH) return done(new Error(`Password exceeds ${PASSWORD_MAX_LENGTH} characters. No files changed.`));
      value += text;
    };
    emitKeypressEvents(process.stdin);
    process.stdin.on('keypress', keypress);
    process.stdin.setRawMode(true);
    process.stdin.resume();
  });
}

async function main() {
  if (process.argv.length > 2) throw new Error('Run without arguments. Passwords are entered privately at the prompt, never as command-line arguments.');
  if (!process.stdin.isTTY || !process.stdout.isTTY || typeof process.stdin.setRawMode !== 'function') {
    throw new Error('Open an interactive terminal to reset the password. Piped input is intentionally disabled.');
  }
  process.stdout.write('CARELab Carbon Studio — local password rotation\nThis is a temporary client-side gate, not server authentication.\n');
  let password = await readHidden('New password (6–256 characters, hidden): ');
  let confirmation = await readHidden('Repeat password (hidden): ');
  if (password !== confirmation) throw new Error('Passwords do not match. No files changed.');
  await writeAccessConfiguration(password);
  password = confirmation = '';
  process.stdout.write('Salted verifier updated. Rebuild and publish the website to apply it.\nNo password was written to the project or printed.\n');
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  main().catch(error => { process.stderr.write(`${error.message}\n`); process.exitCode = 1; });
}
