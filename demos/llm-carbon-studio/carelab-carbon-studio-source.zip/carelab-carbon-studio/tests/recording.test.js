import test from 'node:test';
import assert from 'node:assert/strict';
import { CaptureSession, recordingFormat, recordingFilename, isMp4Blob, makeMp4 } from '../src/recording.js';

const mp4Bytes = new Uint8Array([0,0,0,24,102,116,121,112,105,115,111,109,0,0,0,0,105,115,111,109,97,118,99,49]);
const mp4 = () => new Blob([mp4Bytes], { type: 'video/mp4' });
const webm = () => new Blob([new Uint8Array([0x1a,0x45,0xdf,0xa3,0,0,0,0])], { type: 'video/webm' });
function stream() {
  const track = new EventTarget();
  track.stops = 0;
  track.stop = () => { track.stops++; };
  return { track, getTracks: () => [track], getVideoTracks: () => [track] };
}
class Recorder {
  constructor(stream, config) { this.state = 'inactive'; this.mimeType = config.mimeType; this.stopCount = 0; }
  start(interval) { this.interval = interval; this.state = 'recording'; }
  pause() { this.state = 'paused'; }
  resume() { this.state = 'recording'; }
  stop() {
    this.stopCount++; this.state = 'inactive';
    queueMicrotask(() => { this.ondataavailable({ data: mp4() }); this.onstop(); });
  }
}

test('format prefers explicit MP4 codec and never chooses unsupported formats', () => {
  assert.equal(recordingFormat(mime => ['video/mp4', 'video/webm'].includes(mime)), 'video/mp4');
  assert.equal(recordingFormat(mime => mime === 'video/webm;codecs=vp8'), 'video/webm;codecs=vp8');
  assert.equal(recordingFormat(() => false), '');
});
test('download extensions accurately describe the container', () => {
  const date = new Date('2026-09-25T12:34:56Z');
  assert.match(recordingFilename('video/mp4;codecs=avc1', date), /2026-09-25T12-34-56-000Z\.mp4$/);
  assert.match(recordingFilename('video/webm', date), /\.webm$/);
});
test('pause excludes wall-clock downtime and stop freezes duration', async () => {
  let now = 100;
  const media = stream();
  const session = new CaptureSession(media, 'video/mp4', 1000, () => {}, { Recorder, now: () => now });
  session.start(); now = 1100; session.pause();
  now = 9100; assert.equal(session.duration(), 1000);
  session.resume(); now = 10100; session.stop();
  session.stop(); now = 18100;
  const result = await session.done;
  assert.equal(result.duration, 2000);
  assert.equal(session.duration(), 2000);
  assert.equal(result.blob.size, mp4Bytes.length);
  assert.equal(session.recorder.stopCount, 1);
  assert.equal(media.track.stops, 1);
});
test('ending browser share finalizes and releases the capture track', async () => {
  const media = stream();
  const session = new CaptureSession(media, 'video/mp4', 1000, () => {}, { Recorder });
  session.start(); media.track.dispatchEvent(new Event('ended'));
  const result = await session.done;
  assert.equal(result.reason, 'sharing-ended');
  assert.equal(session.state, 'stopped');
  assert.equal(media.track.stops, 1);
});
test('byte limit finalizes once, retaining the final event payload', async () => {
  const session = new CaptureSession(stream(), 'video/mp4', 1000, () => {}, { Recorder, maxBytes: 10 });
  session.start(); session.recorder.ondataavailable({ data: mp4() });
  const result = await session.done;
  assert.equal(result.reason, 'limit');
  assert.equal(session.recorder.stopCount, 1);
  assert.equal(result.blob.size, 2 * mp4Bytes.length);
});
test('encoder failure preserves subsequent final dataavailable', async () => {
  const session = new CaptureSession(stream(), 'video/mp4', 1000, () => {}, { Recorder });
  session.start(); session.recorder.state = 'inactive'; session.recorder.onerror();
  session.recorder.ondataavailable({ data: mp4() }); session.recorder.onstop();
  const result = await session.done;
  assert.equal(result.reason, 'encoder');
  assert.equal(result.blob.size, mp4Bytes.length);
});
test('start failure releases stream and rejects without a dangling capture', async () => {
  class BrokenRecorder extends Recorder { start() { throw new Error('cannot encode'); } }
  const media = stream(), session = new CaptureSession(media, 'video/mp4', 1000, () => {}, { Recorder: BrokenRecorder });
  assert.throws(() => session.start(), /cannot encode/);
  await assert.rejects(session.done, /cannot encode/);
  assert.equal(media.track.stops, 1);
});
test('empty capture rejects instead of offering an empty MP4', async () => {
  const session = new CaptureSession(stream(), 'video/mp4', 1000, () => {}, { Recorder });
  session.start(); session.recorder.onstop();
  await assert.rejects(session.done, /empty/);
});
test('MP4 detection uses actual bytes, not filename or declared MIME', async () => {
  assert.equal(await isMp4Blob(mp4()), true);
  assert.equal(await isMp4Blob(new Blob([await webm().arrayBuffer()], { type: 'video/mp4' })), false);
  assert.equal(await isMp4Blob(new Blob(['ftyp is not a real box'])), false);
  assert.equal(await isMp4Blob(new Blob()), false);
});
test('native MP4 is not re-encoded or made dependent on the conversion package', async () => {
  const original = mp4();
  const result = await makeMp4(original, { load: () => { throw new Error('must not import'); } });
  assert.equal(result, original);
});

function fakeConverter({ valid = true, bytes = mp4Bytes, during } = {}) {
  const calls = { disposed: false, canceled: false, executed: false };
  class Input { dispose() { calls.disposed = true; } }
  class Output { constructor(options) { this.target = options.target; } }
  class BufferTarget { buffer = null; }
  class Empty {}
  return { calls, library: { Input, Output, BufferTarget, BlobSource: Empty, Mp4OutputFormat: Empty, ALL_FORMATS: [], Conversion: { async init(options) {
    calls.options = options;
    return { isValid: valid, async cancel() { calls.canceled = true; }, async execute() { calls.executed = true; during?.(); options.output.target.buffer = bytes; } };
  } } } };
}
test('WebM is actually routed through AVC/MP4 conversion and cleaned up', async () => {
  const fake = fakeConverter();
  const result = await makeMp4(webm(), { load: async () => fake.library });
  assert.equal(result.type, 'video/mp4');
  assert.equal(await isMp4Blob(result), true);
  assert.equal(fake.calls.options.video.codec, 'avc');
  assert.equal(fake.calls.options.audio.discard, true);
  assert.equal(fake.calls.executed, true);
  assert.equal(fake.calls.disposed, true);
});
test('unsupported conversion rejects honestly and cleans resources', async () => {
  const fake = fakeConverter({ valid: false });
  await assert.rejects(makeMp4(webm(), { load: async () => fake.library }), /mp4-unsupported/);
  assert.equal(fake.calls.executed, false);
  assert.equal(fake.calls.canceled, true);
  assert.equal(fake.calls.disposed, true);
});
test('converter output that is still WebM cannot be downloaded as MP4', async () => {
  const fake = fakeConverter({ bytes: new Uint8Array(await webm().arrayBuffer()) });
  await assert.rejects(makeMp4(webm(), { load: async () => fake.library }), /invalid-mp4/);
  assert.equal(fake.calls.disposed, true);
});
test('conversion cancellation does not return or relabel original data', async () => {
  const controller = new AbortController();
  const fake = fakeConverter({ during: () => controller.abort() });
  await assert.rejects(makeMp4(webm(), { signal: controller.signal, load: async () => fake.library }), error => error.name === 'AbortError');
  assert.equal(fake.calls.canceled, true);
  assert.equal(fake.calls.disposed, true);
});
