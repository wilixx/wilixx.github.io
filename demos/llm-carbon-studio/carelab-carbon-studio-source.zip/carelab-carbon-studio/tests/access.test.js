import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm, rmdir } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { ACCESS_CONFIG, createAccessConfig, verifyAccessPassword, validateAccessConfig, validAccessPassword } from '../src/access.js';
import { writeAccessConfiguration } from '../scripts/set-access-password.mjs';

const fixturePassword = 'Research-demo-test-27';
const fixture = await createAccessConfig(fixturePassword, { iterations: 100000 });

test('password verification accepts the exact value and rejects other values', async () => {
  assert.equal(await verifyAccessPassword(fixturePassword, fixture), true);
  assert.equal(await verifyAccessPassword('Another-demo-test-27', fixture), false);
  assert.equal(await verifyAccessPassword(fixturePassword.toLowerCase(), fixture), false);
  assert.equal(await verifyAccessPassword(`${fixturePassword} `, fixture), false);
});

test('separate configurations have unique random salts and verifiers', async () => {
  const other = await createAccessConfig(fixturePassword, { iterations: 100000 });
  assert.notEqual(other.salt, fixture.salt);
  assert.notEqual(other.verifier, fixture.verifier);
  assert.equal(await verifyAccessPassword(fixturePassword, other), true);
});

test('Unicode passwords round-trip without normalization or trimming', async () => {
  const password = ' 科研演示-test-🔬';
  const config = await createAccessConfig(password, { iterations: 100000 });
  assert.equal(await verifyAccessPassword(password, config), true);
  assert.equal(await verifyAccessPassword(password.trim(), config), false);
});

test('empty, short, non-string, and oversized passwords fail without derivation', async () => {
  for (const password of ['', 'short', null, undefined, 123456, 'x'.repeat(257)]) {
    assert.equal(validAccessPassword(password), false);
    assert.equal(await verifyAccessPassword(password, fixture), false);
    await assert.rejects(createAccessConfig(password));
  }
  assert.equal(validAccessPassword('a'.repeat(256)), true);
});

test('configuration rejects invalid algorithms, excessive work, and malformed byte encodings', () => {
  for (const patch of [
    { enabled: 'yes' }, { version: 2 }, { algorithm: 'SHA-256' }, { digest: 'SHA-1' },
    { iterations: 0 }, { iterations: 99999 }, { iterations: 2000001 }, { iterations: 100000.5 },
    { salt: 'bad' }, { salt: btoa('short') }, { salt: 'A'.repeat(132) },
    { verifier: 'not_base64!' }, { verifier: btoa('short') },
  ]) assert.throws(() => validateAccessConfig({ ...fixture, ...patch }), /Invalid access configuration/);
  assert.throws(() => validateAccessConfig(null), /Invalid access configuration/);
});

test('tampering with a same-length verifier fails verification', async () => {
  const bytes = Uint8Array.from(atob(fixture.verifier), char => char.charCodeAt(0));
  bytes[bytes.length - 1] ^= 1;
  const tampered = { ...fixture, verifier: btoa(String.fromCharCode(...bytes)) };
  assert.equal(await verifyAccessPassword(fixturePassword, tampered), false);
});

test('verification never creates persistent browser state', async () => {
  const previousLocal = Object.getOwnPropertyDescriptor(globalThis, 'localStorage');
  const previousSession = Object.getOwnPropertyDescriptor(globalThis, 'sessionStorage');
  const fail = () => { throw new Error('Browser storage accessed'); };
  Object.defineProperty(globalThis, 'localStorage', { configurable: true, get: fail });
  Object.defineProperty(globalThis, 'sessionStorage', { configurable: true, get: fail });
  try {
    assert.equal(await verifyAccessPassword(fixturePassword, fixture), true);
    assert.equal(await verifyAccessPassword('incorrect-password', fixture), false);
  } finally {
    if (previousLocal) Object.defineProperty(globalThis, 'localStorage', previousLocal); else delete globalThis.localStorage;
    if (previousSession) Object.defineProperty(globalThis, 'sessionStorage', previousSession); else delete globalThis.sessionStorage;
  }
});

test('distributed configuration has a supported salted verifier and switch', () => {
  const bytes = validateAccessConfig(ACCESS_CONFIG);
  assert.equal(typeof ACCESS_CONFIG.enabled, 'boolean');
  assert.equal(ACCESS_CONFIG.iterations, 600000);
  assert.ok(bytes.salt.length >= 16);
  assert.equal(bytes.verifier.length, 32);
  assert.ok(Object.isFrozen(ACCESS_CONFIG));
});

test('local rotation writes only the verifier and changes the accepted password', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'carelab-access-test-'));
  const file = join(directory, 'access-config.js');
  try {
    const first = await writeAccessConfiguration(fixturePassword, file);
    const nextPassword = 'Rotated-demo-password-28';
    const second = await writeAccessConfiguration(nextPassword, file);
    const saved = await readFile(file, 'utf8');
    assert.equal(saved.includes(fixturePassword), false);
    assert.equal(saved.includes(nextPassword), false);
    assert.notEqual(first.salt, second.salt);
    assert.equal(await verifyAccessPassword(nextPassword, second), true);
    assert.equal(await verifyAccessPassword(fixturePassword, second), false);
  } finally {
    await rm(file, { force: true });
    await rmdir(directory);
  }
});

test('reset command rejects command-line passwords and piped input', () => {
  const script = fileURLToPath(new URL('../scripts/set-access-password.mjs', import.meta.url));
  const argumentResult = spawnSync(process.execPath, [script, 'not-a-real-secret'], { encoding: 'utf8' });
  assert.equal(argumentResult.status, 1);
  assert.match(argumentResult.stderr, /without arguments/);
  assert.equal(argumentResult.stderr.includes('not-a-real-secret'), false);
  const pipeResult = spawnSync(process.execPath, [script], { input: fixturePassword, encoding: 'utf8' });
  assert.equal(pipeResult.status, 1);
  assert.match(pipeResult.stderr, /interactive terminal/);
  assert.equal(pipeResult.stdout.includes(fixturePassword), false);
});
