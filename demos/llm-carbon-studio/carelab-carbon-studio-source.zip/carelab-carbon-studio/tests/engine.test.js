import test from 'node:test';
import assert from 'node:assert/strict';
import GLPK from 'glpk.js/node';
import {
  DEFAULTS, METHODS, demoDag, generateDag, normalizeInput,
  solveHeuristic, solveMilp, validateSchedule, ledgerAt,
} from '../src/engine.js';

const heuristicIds = ['serial', 'random', 'list', 'aware', 'reserve'];
const config = { ...DEFAULTS, servers: 2, channels: 2, idleW: 37, busyW: 211, networkW: 19, pue: 1.17, ci: 423, tuSeconds: 2.5 };
const near = (actual, expected, message = '') => assert.ok(
  Math.abs(actual - expected) <= 1e-6 * Math.max(1, Math.abs(expected)),
  `${message}: expected ${expected}, got ${actual}`,
);
const makeDag = (durations, edges = [], options = config) => normalizeInput({
  nodes: durations.map((duration, id) => ({ id, duration })),
  edges: edges.map(([source, target, duration]) => ({ source, target, duration })),
  seed: 12,
}, options);
const overlap = (a, b) => Math.max(0, Math.min(a.end, b.end) - Math.max(a.start, b.start));

// Independent checks ensure that validator regressions cannot make solvers pass.
function assertPhysical(dag, result) {
  assert.equal(result.tasks.length, dag.nodes.length);
  const tasks = new Map(result.tasks.map(task => [task.id, task]));
  assert.equal(tasks.size, dag.nodes.length);
  for (const node of dag.nodes) {
    const task = tasks.get(node.id);
    assert.ok(task, `missing task ${node.id}`);
    assert.ok(Number.isInteger(task.resource) && task.resource >= 0 && task.resource < dag.resources.servers);
    assert.ok(task.start >= -1e-7);
    near(task.end - task.start, node.duration, `task ${node.id} duration`);
  }
  for (let i = 0; i < result.tasks.length; i++) {
    for (const other of result.tasks.slice(i + 1)) {
      if (result.tasks[i].resource === other.resource) near(overlap(result.tasks[i], other), 0, 'server mutex');
    }
  }
  for (const edge of dag.edges) {
    const source = tasks.get(edge.source), target = tasks.get(edge.target);
    const flows = result.flows.filter(flow => flow.source === edge.source && flow.target === edge.target);
    if (source.resource === target.resource) {
      assert.equal(flows.length, 0, 'local edge must not consume network');
      assert.ok(target.start + 1e-6 >= source.end);
    } else {
      assert.equal(flows.length, 1, 'cross-host edge needs exactly one flow, including zero-duration edges');
      const flow = flows[0];
      assert.ok(Number.isInteger(flow.resource) && flow.resource >= 0 && flow.resource < dag.resources.channels);
      near(flow.end - flow.start, edge.duration, 'flow duration');
      assert.ok(flow.start + 1e-6 >= source.end);
      assert.ok(target.start + 1e-6 >= flow.end);
    }
  }
  for (let i = 0; i < result.flows.length; i++) {
    for (const other of result.flows.slice(i + 1)) {
      if (result.flows[i].resource === other.resource) near(overlap(result.flows[i], other), 0, 'channel mutex');
    }
  }
  near(result.completion_time, Math.max(...result.tasks.map(task => task.end)), 'completion time');
  assert.equal(validateSchedule(dag, result), true);
}

test('public defaults, methods, and demo are available', () => {
  assert.ok(DEFAULTS.servers > 0 && DEFAULTS.channels > 0);
  assert.ok(METHODS);
  const raw = typeof demoDag === 'function' ? demoDag() : demoDag;
  assert.ok(normalizeInput(raw).nodes.length > 0);
});

test('normalization uses explicit resource settings and preserves numeric IDs', () => {
  const result = normalizeInput({ nodes: [{ id: 7, duration: 0.25 }, { id: 42, duration: 1.5 }], edges: [{ source: 7, target: 42, duration: 0 }], resources: { servers: 4, channels: 3 }, seed: 91 }, { ...config, servers: 2, channels: 1 });
  assert.deepEqual(result.nodes.map(node => node.id), [7, 42]);
  assert.deepEqual(result.resources, { servers: 2, channels: 1 });
  assert.equal(result.seed, config.seed, 'explicit configuration seed takes precedence');
  assert.equal(normalizeInput({ nodes: [{ id: 7, duration: 1 }], edges: [], seed: 91 }).seed, 91);
});

const invalidInputs = [
  ['empty graph', { nodes: [], edges: [] }],
  ['duplicate node ID', { nodes: [{ id: 0, duration: 1 }, { id: 0, duration: 2 }], edges: [] }],
  ['zero node duration', { nodes: [{ id: 0, duration: 0 }], edges: [] }],
  ['negative node duration', { nodes: [{ id: 0, duration: -1 }], edges: [] }],
  ['nonfinite node duration', { nodes: [{ id: 0, duration: Infinity }], edges: [] }],
  ['missing endpoint', { nodes: [{ id: 0, duration: 1 }], edges: [{ source: 0, target: 9, duration: 1 }] }],
  ['self edge', { nodes: [{ id: 0, duration: 1 }], edges: [{ source: 0, target: 0, duration: 0 }] }],
  ['negative edge duration', { nodes: [{ id: 0, duration: 1 }, { id: 1, duration: 1 }], edges: [{ source: 0, target: 1, duration: -0.1 }] }],
  ['cycle', { nodes: [{ id: 0, duration: 1 }, { id: 1, duration: 1 }], edges: [{ source: 0, target: 1, duration: 0 }, { source: 1, target: 0, duration: 0 }] }],
];
for (const [name, input] of invalidInputs) test(`rejects ${name}`, () => assert.throws(() => normalizeInput(input, config)));

test('invalid resource counts are rejected', () => {
  for (const changes of [{ servers: 0 }, { servers: 9 }, { servers: 1.5 }, { channels: 0 }, { channels: 9 }]) {
    assert.throws(() => makeDag([1], [], { ...config, ...changes }));
  }
});

for (const kind of ['pipeline', 'forkjoin', 'mapreduce', 'diamond', 'layered', 'random', 'tree', 'independent']) {
  test(`${kind} generation is deterministic and produces a schedulable DAG`, () => {
    const raw = generateDag(kind, 10, 713);
    assert.deepEqual(raw, generateDag(kind, 10, 713));
    const dag = normalizeInput(raw, config);
    assert.ok(dag.nodes.length > 0);
    assertPhysical(dag, solveHeuristic(dag, 'list'));
  });
}

for (const method of heuristicIds) {
  test(`${method} obeys physical constraints and the affine carbon identity`, () => {
    const dag = makeDag([0.5, 1.75, 0.25, 2.125, 0.875, 1.5], [[0, 2, 0.4], [1, 3, 0.75], [2, 4, 0], [3, 4, 0.3], [4, 5, 0.6]]);
    const result = solveHeuristic(dag, method);
    assertPhysical(dag, result);
    assert.ok(Number.isFinite(result.runtime_ms) && result.runtime_ms >= 0);
    assert.ok(result.status);
    const end = ledgerAt(dag, result, config, result.completion_time);
    const work = dag.nodes.reduce((sum, node) => sum + node.duration, 0);
    const fixedJ = (config.busyW - config.idleW) * work * config.tuSeconds;
    const reservationJ = (dag.resources.servers * config.idleW + config.networkW) * result.completion_time * config.tuSeconds;
    const factor = config.pue * config.ci / 3.6e6;
    near(end.totalJ, fixedJ + reservationJ, 'energy identity');
    near(end.totalG, (fixedJ + reservationJ) * factor, 'carbon identity');
    near(end.fixedG, fixedJ * factor, 'fixed compute increment');
    near(end.reservationG, reservationJ * factor, 'reservation baseline');
    near(end.totalG, end.fixedG + end.reservationG, 'decomposition');
    near(end.totalG, end.servers.reduce((sum, server) => sum + server.carbonG, 0) + end.network.carbonG, 'ledger conservation');
    let previous = -1;
    for (let i = 0; i <= 50; i++) {
      const sample = ledgerAt(dag, result, config, result.completion_time * i / 50);
      assert.ok(sample.totalG + 1e-9 >= previous, 'cumulative carbon cannot decrease');
      previous = sample.totalG;
    }
  });
}

test('seeded random scheduling is reproducible', () => {
  const dag = normalizeInput(generateDag('random', 12, 717), config);
  const first = solveHeuristic(dag, 'random'), second = solveHeuristic(dag, 'random');
  assert.deepEqual(first.tasks, second.tasks);
  assert.deepEqual(first.flows, second.flows);
});

const fractionalDag = makeDag([0.25, 0.5, 0.75, 0.25], [[0, 3, 0.3], [1, 2, 0.3]]);
const fractionalSchedule = {
  tasks: [{ id: 0, resource: 0, start: 0, end: 0.25 }, { id: 1, resource: 1, start: 0, end: 0.5 }, { id: 2, resource: 0, start: 0.8, end: 1.55 }, { id: 3, resource: 1, start: 1.2, end: 1.45 }],
  flows: [{ source: 0, target: 3, resource: 0, start: 0.25, end: 0.55 }, { source: 1, target: 2, resource: 1, start: 0.5, end: 0.8 }],
  completion_time: 1.55, status: 'manual', runtime_ms: 0,
};

test('fractional ledger integrates exact intervals independently of playback sampling', () => {
  assertPhysical(fractionalDag, fractionalSchedule);
  for (const t of [0, 0.123, 0.25, 0.5, 0.55, 0.8, 0.93, 1.2, 1.45, 1.55]) {
    const ledger = ledgerAt(fractionalDag, fractionalSchedule, config, t);
    let energy = config.networkW * t * config.tuSeconds;
    for (const server of ledger.servers) {
      const busy = fractionalSchedule.tasks.filter(task => task.resource === server.resource).reduce((sum, task) => sum + Math.max(0, Math.min(t, task.end) - task.start), 0) * config.tuSeconds;
      near(server.busySeconds, busy, 'exact busy seconds');
      near(server.idleSeconds, t * config.tuSeconds - busy, 'exact idle seconds');
      const expectedJ = config.idleW * t * config.tuSeconds + (config.busyW - config.idleW) * busy;
      near(server.energyJ, expectedJ, 'exact integrated server energy');
      energy += expectedJ;
    }
    near(ledger.totalJ, energy, 'analytic energy at fractional time');
  }
  const before = ledgerAt(fractionalDag, fractionalSchedule, config, 0.73);
  for (const t of [0.1, 0.2, 0.9, 1.5, 0.3]) ledgerAt(fractionalDag, fractionalSchedule, config, t);
  assert.deepEqual(ledgerAt(fractionalDag, fractionalSchedule, config, 0.73), before, 'ledger must be a stateless function of time');
});

test('ledger clamps playback and stops all instantaneous power after completion', () => {
  const start = ledgerAt(fractionalDag, fractionalSchedule, config, -10);
  assert.equal(start.time, 0);
  near(start.totalJ, 0);
  const end = ledgerAt(fractionalDag, fractionalSchedule, config, fractionalSchedule.completion_time);
  const late = ledgerAt(fractionalDag, fractionalSchedule, config, 1000);
  assert.equal(late.time, fractionalSchedule.completion_time);
  assert.equal(late.finished, true);
  near(late.totalG, end.totalG);
  assert.equal(late.network.powerW, 0);
  for (const server of late.servers) assert.equal(server.powerW, 0);
});

test('zero-duration cross-host transfers are retained and consume no channel interval', () => {
  const dag = makeDag([1, 1, 0.5, 1], [[0, 1, 0], [0, 3, 1]], { ...config, channels: 1 });
  const result = { tasks: [{ id: 0, resource: 0, start: 0, end: 1 }, { id: 1, resource: 1, start: 1, end: 2 }, { id: 2, resource: 0, start: 1, end: 1.5 }, { id: 3, resource: 1, start: 2, end: 3 }], flows: [{ source: 0, target: 1, resource: 0, start: 1, end: 1 }, { source: 0, target: 3, resource: 0, start: 1, end: 2 }], completion_time: 3 };
  assertPhysical(dag, result);
  assert.throws(() => validateSchedule(dag, { ...result, flows: result.flows.slice(1) }));
});

test('two channels admit simultaneous transfers and a shorter valid schedule', () => {
  const dag = makeDag([1, 1, 1, 1], [[0, 2, 2], [1, 3, 2]]);
  const parallel = { tasks: [{ id: 0, resource: 0, start: 0, end: 1 }, { id: 1, resource: 1, start: 0, end: 1 }, { id: 2, resource: 1, start: 3, end: 4 }, { id: 3, resource: 0, start: 3, end: 4 }], flows: [{ source: 0, target: 2, resource: 0, start: 1, end: 3 }, { source: 1, target: 3, resource: 1, start: 1, end: 3 }], completion_time: 4 };
  assertPhysical(dag, parallel);
  const single = normalizeInput(dag, { ...config, channels: 1 });
  const serial = structuredClone(parallel);
  serial.flows[1] = { ...serial.flows[1], resource: 0, start: 3, end: 5 };
  serial.tasks[3] = { ...serial.tasks[3], start: 5, end: 6 };
  serial.completion_time = 6;
  assertPhysical(single, serial);
  assert.ok(parallel.completion_time < serial.completion_time);
  assert.throws(() => validateSchedule(single, parallel));
});

test('validator rejects server overlap, broken precedence, and altered durations', () => {
  for (const mutate of [
    result => { result.tasks[2].start = 0.1; result.tasks[2].end = 0.85; },
    result => { result.flows[1].start = 0.1; result.flows[1].end = 0.4; },
    result => { result.tasks[0].end = 0.3; },
  ]) {
    const invalid = structuredClone(fractionalSchedule);
    mutate(invalid);
    assert.throws(() => validateSchedule(fractionalDag, invalid));
  }
});

const glpkPromise = GLPK();
for (const [name, durations, edges, optimum] of [
  ['three-task chain', [1, 2, 3], [[0, 1, 2], [1, 2, 2]], 6],
  ['three independent equal tasks', [2, 2, 2], [], 4],
  ['fractional fork', [0.5, 0.75, 0.75], [[0, 1, 0.125], [0, 2, 0.125]], 1.375],
]) {
  test(`real GLPK proves the analytic optimum for ${name}`, async () => {
    const dag = makeDag(durations, edges);
    const result = await solveMilp(dag, { ...config, milpTimeLimit: 10 }, await glpkPromise);
    assertPhysical(dag, result);
    near(result.completion_time, optimum, 'known optimal makespan');
    assert.match(String(result.status), /optimal/i, 'must report proved optimality');
  });
}

test('MILP size guard returns an explicit, physically valid heuristic fallback', async () => {
  const dag = normalizeInput(generateDag('independent', 15, 4), config);
  const result = await solveMilp(dag, config, { solve() { throw new Error('Size guard must skip GLPK'); } });
  assert.equal(result.method, 'milp');
  assert.equal(result.status, 'fallback');
  assert.equal(result.solver_ran, false);
  assert.equal(result.optimal, false);
  assert.match(result.note, /14 tasks/);
  assertPhysical(dag, result);
});

test('MILP unavailable or unvalidated output never acquires an optimality certificate', async () => {
  const dag = makeDag([1, 2, 1], [[0, 2, 0.5]]);
  const missing = await solveMilp(dag, config);
  assert.equal(missing.status, 'fallback');
  assert.equal(missing.solver_ran, false);
  assertPhysical(dag, missing);
  const real = await glpkPromise;
  const invalid = await solveMilp(dag, config, { ...real, solve: () => ({ result: { status: real.GLP_OPT, vars: {} } }) });
  assert.equal(invalid.status, 'fallback');
  assert.equal(invalid.optimal, false);
  assert.match(invalid.note, /validation/);
  assertPhysical(dag, invalid);
});

test('MILP budget reaches GLPK as seconds and solver timeout is honestly labelled', async () => {
  const dag = makeDag([1, 2, 1], [[0, 2, 0.5]]);
  const real = await glpkPromise;
  const limited = { ...real, solve: (_model, options) => {
    assert.ok(options.tmlim > 0 && options.tmlim <= 0.25);
    assert.equal(options.mipgap, 0);
    return { result: { status: real.GLP_UNDEF, vars: {} } };
  } };
  const result = await solveMilp(dag, { ...config, milpTimeLimit: 0.25 }, limited);
  assert.equal(result.status, 'fallback');
  assert.equal(result.solver_ran, true);
  assert.equal(result.optimal, false);
  assertPhysical(dag, result);
});

test('invalid power, unit, seed, and accounting parameters are rejected', () => {
  for (const patch of [{ busyW: 1, idleW: 2 }, { idleW: -1 }, { networkW: -1 }, { pue: 0.9 }, { ci: NaN }, { tuSeconds: 0 }, { seed: 1.2 }, { milpTimeLimit: 0 }]) {
    assert.throws(() => normalizeInput(demoDag(), { ...DEFAULTS, ...patch }));
  }
});

test('the shared demonstration exhibits distinct executable schedules and real transfers', () => {
  const dag = normalizeInput(demoDag(), DEFAULTS);
  const results = heuristicIds.map(method => solveHeuristic(dag, method));
  assert.equal(new Set(results.map(result => result.completion_time)).size, results.length);
  for (const result of results) {
    assertPhysical(dag, result);
    if (result.method !== 'serial') assert.ok(result.flows.length > 0);
  }
  const byMethod = Object.fromEntries(results.map(result => [result.method, result]));
  assert.ok(byMethod.reserve.completion_time <= byMethod.aware.completion_time);
});
