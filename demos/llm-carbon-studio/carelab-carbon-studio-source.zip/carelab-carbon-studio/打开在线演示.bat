@echo off
start "" "https://wilixx.github.io/demos/llm-carbon-studio/"
