import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({plugins:[react()],base:'./',worker:{format:'es'},build:{sourcemap:false,chunkSizeWarningLimit:850},server:{host:'127.0.0.1',port:5190,strictPort:true}});
