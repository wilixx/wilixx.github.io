/* Homogeneous reserved-resource DAG scheduling. All intervals are half-open.
 * Time is in tu; only the accounting boundary converts tu to seconds.
 * Ported from carelab-reserved/simulation/{heuristics,milp}.py and reservation.py.
 */
export const DEFAULTS = Object.freeze({ servers: 3, channels: 2, idleW: 70, busyW: 320, networkW: 25, pue: 1.2, ci: 400, tuSeconds: 1, seed: 12, milpTimeLimit: 5 });
export const METHODS = Object.freeze([
  { id: 'list', en: 'List scheduling', zh: '列表调度', color: '#38bdf8' },
  { id: 'random', en: 'Seeded random', zh: '种子随机', color: '#fb7185' },
  { id: 'aware', en: 'Network-aware list', zh: '通信感知列表', color: '#a78bfa' },
  { id: 'reserve', en: 'CARE Reserve search', zh: 'CARE 预留搜索', color: '#34d399' },
  { id: 'serial', en: 'Serial', zh: '串行调度', color: '#fbbf24' },
  { id: 'milp', en: 'GLPK MILP', zh: 'GLPK 混合整数规划', color: '#fb923c' },
]);
const EPS = 1e-7;
const now = () => performance.now();
const sum = values => values.reduce((a, b) => a + b, 0);
const key = edge => `${edge.source}:${edge.target}`;
function randomSource(seed) {
  let a = seed >>> 0;
  return () => { a += 0x6d2b79f5; let t = a; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}
function numeric(value, label, min, max, integer = false) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max || integer && !Number.isInteger(value)) {
    throw new Error(`${label} must be ${integer ? 'an integer' : 'a finite number'} from ${min} to ${max}.`);
  }
  return value;
}
function configuration(config = {}, resources = {}) {
  const cfg = { ...DEFAULTS, ...resources, ...config };
  numeric(cfg.servers, 'Servers', 1, 8, true);
  numeric(cfg.channels, 'Channels', 1, 8, true);
  numeric(cfg.idleW, 'Idle power', 0, 1e6);
  numeric(cfg.busyW, 'Busy power', cfg.idleW, 1e6);
  numeric(cfg.networkW, 'Network power', 0, 1e6);
  numeric(cfg.pue, 'PUE', 1, 10);
  numeric(cfg.ci, 'Carbon intensity', 0, 5000);
  numeric(cfg.tuSeconds, 'Seconds per time unit', 0.001, 86400);
  numeric(cfg.seed, 'Seed', 0, 4294967295, true);
  numeric(cfg.milpTimeLimit, 'MILP time limit in seconds', 0.01, 60);
  return cfg;
}
function topology(dag) {
  const parents = new Map(dag.nodes.map(n => [n.id, []]));
  const children = new Map(dag.nodes.map(n => [n.id, []]));
  for (const edge of dag.edges) { parents.get(edge.target).push(edge); children.get(edge.source).push(edge); }
  const indegree = new Map([...parents].map(([id, edges]) => [id, edges.length]));
  const ready = dag.nodes.filter(n => !indegree.get(n.id)).map(n => n.id).sort((a, b) => a - b);
  const order = [];
  while (ready.length) {
    const id = ready.shift(); order.push(id);
    for (const edge of children.get(id)) {
      const n = indegree.get(edge.target) - 1; indegree.set(edge.target, n);
      if (!n) { ready.push(edge.target); ready.sort((a, b) => a - b); }
    }
  }
  if (order.length !== dag.nodes.length) throw new Error('The graph contains a cycle; upload a directed acyclic graph.');
  return { order, parents, children };
}
export function normalizeInput(input, config = {}) {
  if (!input || !Array.isArray(input.nodes) || !Array.isArray(input.edges)) throw new Error('A DAG needs nodes and edges arrays.');
  if (input.nodes.length < 1 || input.nodes.length > 32) throw new Error('Use 1–32 tasks.');
  if (input.edges.length > 496) throw new Error('Use at most 496 unique edges.');
  const cfg = configuration({ ...(input.seed === undefined ? {} : { seed: input.seed }), ...config }, input.resources);
  const seen = new Set();
  const nodes = input.nodes.map(node => {
    numeric(node.id, 'Task ID', 0, 2147483647, true);
    numeric(node.duration, `Task ${node.id} duration`, 0.001, 10000);
    if (seen.has(node.id)) throw new Error(`Duplicate task ID ${node.id}.`);
    seen.add(node.id);
    return { ...node, id: node.id, duration: node.duration };
  });
  const edgeKeys = new Set();
  const edges = input.edges.map(edge => {
    if (!seen.has(edge.source) || !seen.has(edge.target)) throw new Error('Every edge endpoint must name an existing task.');
    if (edge.source === edge.target) throw new Error('Self edges are not allowed in a DAG.');
    numeric(edge.duration, 'Transfer duration', 0, 10000);
    if (edgeKeys.has(key(edge))) throw new Error(`Duplicate edge ${key(edge)}.`);
    edgeKeys.add(key(edge));
    return { source: edge.source, target: edge.target, duration: edge.duration };
  });
  const dag = { ...input, nodes, edges, resources: { servers: cfg.servers, channels: cfg.channels }, seed: cfg.seed };
  topology(dag);
  return dag;
}
export function generateDag(kind = 'forkjoin', count = 8, seed = 12) {
  numeric(count, 'Task count', 1, 32, true);
  numeric(seed, 'Seed', 0, 4294967295, true);
  const kinds = ['pipeline', 'forkjoin', 'mapreduce', 'diamond', 'layered', 'random', 'tree', 'independent'];
  if (!kinds.includes(kind)) throw new Error(`Unknown DAG family ${kind}.`);
  const random = randomSource(seed), nodes = Array.from({ length: count }, (_, id) => ({ id, duration: 2 + Math.floor(random() * 7) }));
  const edges = [], seen = new Set();
  const add = (source, target) => {
    if (source >= target || source < 0 || target >= count || seen.has(`${source}:${target}`)) return;
    seen.add(`${source}:${target}`); edges.push({ source, target, duration: 1 + Math.floor(random() * 4) });
  };
  if (kind === 'pipeline') for (let i = 1; i < count; i++) add(i - 1, i);
  if (kind === 'forkjoin') for (let i = 1; i < count - 1; i++) { add(0, i); add(i, count - 1); }
  if (kind === 'forkjoin' && count === 2) add(0, 1);
  if (kind === 'mapreduce') {
    const split = Math.ceil(count / 2);
    for (let i = 0; i < split; i++) for (let j = split; j < count; j++) add(i, j);
  }
  if (kind === 'diamond') {
    for (let i = 0; i < count - 1; i += 3) { add(i, i + 1); add(i, i + 2); add(i + 1, i + 3); add(i + 2, i + 3); }
  }
  if (kind === 'layered') {
    const width = Math.max(2, Math.ceil(Math.sqrt(count)));
    for (let i = 0; i < count; i++) for (let j = i + 1; j < count; j++) {
      if (Math.floor(j / width) === Math.floor(i / width) + 1 && (j % width === i % width || random() < 0.55)) add(i, j);
    }
  }
  if (kind === 'random') for (let i = 0; i < count; i++) for (let j = i + 1; j < count; j++) if (random() < 0.24) add(i, j);
  if (kind === 'tree') for (let i = 1; i < count; i++) add(Math.floor((i - 1) / 2), i);
  return { name: kind, nodes, edges, seed, resources: { servers: DEFAULTS.servers, channels: DEFAULTS.channels } };
}
export function demoDag() {
  // Chosen for visible shared-channel contention, with no scripted outcomes.
  return { ...generateDag('forkjoin', 8, 70), name: 'Shared network · fork and join', seed: DEFAULTS.seed };
}
function gap(calendar, release, duration) {
  if (duration === 0) return release; // Empty transfers occupy no channel capacity.
  let start = release;
  for (const interval of [...calendar].sort((a, b) => a.start - b.start || a.end - b.end)) {
    if (start + duration <= interval.start + EPS) break;
    if (start < interval.end) start = interval.end;
  }
  return start;
}
function schedule(dag, policy, options = {}) {
  const random = randomSource(options.seed ?? dag.seed);
  const { order, parents, children } = topology(dag);
  const duration = new Map(dag.nodes.map(n => [n.id, n.duration])), rank = new Map();
  for (const id of [...order].reverse()) rank.set(id, duration.get(id) + Math.max(0, ...children.get(id).map(e => rank.get(e.target) + (policy === 'list' ? 0 : e.duration))));
  const cpu = Array.from({ length: dag.resources.servers }, () => []);
  let net = Array.from({ length: dag.resources.channels }, () => []);
  const done = new Map(), flows = [];
  while (done.size < duration.size) {
    const ready = order.filter(id => !done.has(id) && parents.get(id).every(edge => done.has(edge.source)));
    ready.sort((a, b) => options.priority ? (options.priority.get(a) ?? 1e6) - (options.priority.get(b) ?? 1e6) || rank.get(b) - rank.get(a) || a - b : rank.get(b) - rank.get(a) || a - b);
    const id = policy === 'random' && !options.priority ? ready[Math.floor(random() * ready.length)] : ready[0];
    function candidate(server) {
      const calendar = net.map(c => [...c]), incoming = [];
      let release = 0;
      for (const edge of [...parents.get(id)].sort((a, b) => done.get(a.source).end - done.get(b.source).end || a.source - b.source)) {
        const previous = done.get(edge.source); let end = previous.end;
        if (previous.resource !== server) {
          const choices = calendar.map((c, resource) => ({ start: gap(c, end, edge.duration), resource }));
          choices.sort((a, b) => a.start - b.start || a.resource - b.resource);
          const { start, resource } = choices[0]; end = start + edge.duration;
          const flow = { source: edge.source, target: id, resource, start, end };
          if (edge.duration > 0) calendar[resource].push(flow);
          incoming.push(flow);
        }
        release = Math.max(release, end);
      }
      return { start: gap(cpu[server], release, duration.get(id)), server, incoming, calendar };
    }
    let chosen;
    if (options.forced?.has(id)) chosen = candidate(options.forced.get(id));
    else if (policy === 'serial') chosen = candidate(0);
    else if (policy === 'random') chosen = candidate(Math.floor(random() * cpu.length));
    else if (policy === 'list') {
      // List placement estimates edge latency but ignores shared-channel contention.
      const estimates = cpu.map((calendar, server) => {
        const release = Math.max(0, ...parents.get(id).map(e => done.get(e.source).end + (done.get(e.source).resource === server ? 0 : e.duration)));
        return { server, start: gap(calendar, release, duration.get(id)) };
      }).sort((a, b) => a.start - b.start || a.server - b.server);
      chosen = candidate(estimates[0].server);
    } else {
      chosen = cpu.map((_, server) => candidate(server)).sort((a, b) => a.start - b.start || sum(a.incoming.map(f => f.end - f.start)) - sum(b.incoming.map(f => f.end - f.start)) || a.server - b.server)[0];
    }
    const task = { id, resource: chosen.server, start: chosen.start, end: chosen.start + duration.get(id) };
    done.set(id, task); cpu[task.resource].push(task); net = chosen.calendar; flows.push(...chosen.incoming);
  }
  const tasks = [...done.values()];
  return { tasks, flows, completion_time: Math.max(...tasks.map(t => t.end)) };
}
function reserveSearch(dag) {
  const seeds = ['serial', 'list', 'aware'].map(m => schedule(dag, m));
  for (let i = 0; i < 8; i++) seeds.push(schedule(dag, 'random', { seed: (dag.seed + i) >>> 0 }));
  let best = seeds.sort((a, b) => a.completion_time - b.completion_time)[0];
  let candidates = seeds.length, accepted = 0;
  for (let pass = 0; pass < 2; pass++) {
    let changed = false;
    const priority = new Map([...best.tasks].sort((a, b) => a.start - b.start || a.id - b.id).map((t, i) => [t.id, i]));
    let assignments = new Map(best.tasks.map(t => [t.id, t.resource]));
    for (const node of dag.nodes) for (let server = 0; server < dag.resources.servers; server++) {
      if (server === assignments.get(node.id)) continue;
      const forced = new Map(assignments); forced.set(node.id, server);
      const trial = schedule(dag, 'aware', { forced, priority }); candidates++;
      if (trial.completion_time < best.completion_time - EPS) { best = trial; assignments = forced; changed = true; accepted++; }
    }
    if (!changed) break;
  }
  return { ...best, candidates_evaluated: candidates, accepted_moves: accepted };
}
export function solveHeuristic(input, method = 'aware') {
  const started = now(), dag = normalizeInput(input);
  if (!METHODS.some(m => m.id === method && method !== 'milp')) throw new Error(`Unknown heuristic ${method}.`);
  const result = method === 'reserve' ? reserveSearch(dag) : schedule(dag, method);
  validateSchedule(dag, result);
  return { ...result, method, status: 'heuristic', runtime_ms: now() - started, solver_ran: false, optimal: false, note: 'Validated feasible schedule; global optimality is not proved.', note_zh: '已验证资源约束可行；无全局最优证明。' };
}
export function validateSchedule(input, result) {
  const dag = normalizeInput(input);
  if (!result || !Array.isArray(result.tasks) || !Array.isArray(result.flows)) throw new Error('A schedule needs tasks and flows arrays.');
  if (result.tasks.length !== dag.nodes.length) throw new Error('Schedule must contain every task exactly once.');
  const nodes = new Map(dag.nodes.map(n => [n.id, n])), tasks = new Map();
  const cpu = Array.from({ length: dag.resources.servers }, () => []), net = Array.from({ length: dag.resources.channels }, () => []);
  const validInterval = (item, label) => {
    if (!Number.isFinite(item.start) || !Number.isFinite(item.end) || item.start < -EPS || item.end < item.start - EPS) throw new Error(`${label} has an invalid interval.`);
  };
  for (const task of result.tasks) {
    if (!nodes.has(task.id) || tasks.has(task.id)) throw new Error('Schedule has an unknown or duplicate task.');
    numeric(task.resource, 'Task server', 0, cpu.length - 1, true); validInterval(task, 'Task');
    if (Math.abs(task.end - task.start - nodes.get(task.id).duration) > EPS) throw new Error('A task duration differs from the input.');
    tasks.set(task.id, task); cpu[task.resource].push(task);
  }
  const edges = new Map(dag.edges.map(e => [key(e), e])), flows = new Map();
  for (const flow of result.flows) {
    const edge = edges.get(key(flow));
    if (!edge || flows.has(key(flow))) throw new Error('Schedule has an unknown or duplicate transfer.');
    const source = tasks.get(flow.source), target = tasks.get(flow.target);
    if (source.resource === target.resource) throw new Error('Co-located tasks must not emit a network transfer.');
    numeric(flow.resource, 'Transfer channel', 0, net.length - 1, true); validInterval(flow, 'Transfer');
    if (Math.abs(flow.end - flow.start - edge.duration) > EPS) throw new Error('A transfer duration differs from the input.');
    if (flow.start < source.end - EPS || flow.end > target.start + EPS) throw new Error('Transfer violates predecessor/consumer precedence.');
    flows.set(key(flow), flow); if (edge.duration > 0) net[flow.resource].push(flow);
  }
  for (const edge of dag.edges) {
    const source = tasks.get(edge.source), target = tasks.get(edge.target);
    if (source.end > target.start + EPS) throw new Error('Task precedence is violated.');
    if (source.resource !== target.resource && !flows.has(key(edge))) throw new Error('Every cross-server edge needs a transfer, including zero-duration edges.');
  }
  for (const calendar of [...cpu, ...net]) {
    const sorted = [...calendar].sort((a, b) => a.start - b.start || a.end - b.end);
    for (let i = 1; i < sorted.length; i++) if (sorted[i].start < sorted[i - 1].end - EPS) throw new Error('Resource mutex violated: overlapping intervals.');
  }
  const actual = Math.max(...result.tasks.map(t => t.end));
  if (!Number.isFinite(result.completion_time) || Math.abs(actual - result.completion_time) > EPS) throw new Error('Completion time must equal the last task end.');
  return true;
}
export function ledgerAt(dag, result, config = {}, requestedTime = 0) {
  const cfg = configuration(config, dag.resources);
  if (cfg.servers !== dag.resources.servers || cfg.channels !== dag.resources.channels) throw new Error('Accounting resources must match the scheduled resources.');
  if (typeof requestedTime !== 'number' || Number.isNaN(requestedTime)) throw new Error('Ledger time must be a number.');
  const time = Math.max(0, Math.min(result.completion_time, requestedTime));
  const finished = time >= result.completion_time, seconds = time * cfg.tuSeconds, factor = cfg.pue * cfg.ci / 3600000;
  const servers = Array.from({ length: cfg.servers }, (_, resource) => {
    const tasks = result.tasks.filter(t => t.resource === resource);
    const busySeconds = sum(tasks.map(t => Math.max(0, Math.min(time, t.end) - t.start))) * cfg.tuSeconds;
    const activeTask = finished ? null : tasks.find(t => t.start <= time && time < t.end)?.id ?? null;
    const energyJ = cfg.idleW * seconds + (cfg.busyW - cfg.idleW) * busySeconds;
    return { resource, carbonG: energyJ * factor, energyJ, powerW: finished ? 0 : activeTask === null ? cfg.idleW : cfg.busyW, activeTask, busySeconds, idleSeconds: Math.max(0, seconds - busySeconds) };
  });
  const networkJ = cfg.networkW * seconds;
  const network = { carbonG: networkJ * factor, energyJ: networkJ, powerW: finished ? 0 : cfg.networkW, activeFlows: finished ? [] : result.flows.filter(f => f.start <= time && time < f.end) };
  const totalJ = sum(servers.map(s => s.energyJ)) + networkJ;
  const fixedG = sum(servers.map(s => s.busySeconds)) * (cfg.busyW - cfg.idleW) * factor;
  const reservationG = (cfg.servers * cfg.idleW + cfg.networkW) * seconds * factor;
  return { time, finished, totalG: totalJ * factor, totalJ, servers, network, fixedG, reservationG };
}

/* Continuous starts, binary host assignment, exact transfer activation, and
 * pairwise disjunctions for every host/channel. Objective min T is equivalent
 * to min carbon when the reserved baseline has a strictly positive slope.
 */
export async function solveMilp(input, config = {}, glpk) {
  const started = now(), cfg = configuration({ ...(input.seed === undefined ? {} : { seed: input.seed }), ...config }, input.resources), dag = normalizeInput(input, cfg);
  const seed = solveHeuristic(dag, 'reserve');
  const finish = (result, metadata) => ({ ...result, ...metadata, method: 'milp', runtime_ms: now() - started });
  const fallback = (note, note_zh, solverRan = false, extra = {}) => finish(seed, { status: 'fallback', optimal: false, solver_ran: solverRan, solver_status: null, solver_gap: null, note, note_zh, ...extra });
  if (dag.nodes.length > 14 || dag.edges.length > 35) return fallback('MILP size guard: maximum 14 tasks / 35 edges. Returned a validated CARE Reserve heuristic; no optimality certificate.', '超过 MILP 规模上限（14 个任务 / 35 条边）；返回已验证的 CARE 预留启发式方案，无最优证明。');
  if (!glpk || typeof glpk.solve !== 'function') return fallback('GLPK is unavailable; returned a validated CARE Reserve heuristic.', 'GLPK 不可用；返回已验证的 CARE 预留启发式方案。');
  const B = seed.completion_time, K = dag.resources.servers, C = dag.resources.channels;
  const bounds = [], binaries = [], rows = [], index = new Map(dag.nodes.map((n, i) => [n.id, i]));
  let serial = 0;
  function variable(prefix, binary = true) {
    const name = `${prefix}_${serial++}`;
    if (binary) binaries.push(name); else bounds.push({ name, type: glpk.GLP_DB, lb: 0, ub: B });
    return name;
  }
  function row(terms, lb = -Infinity, ub = Infinity) {
    const combined = new Map(); for (const [name, coef] of terms) combined.set(name, (combined.get(name) || 0) + coef);
    const type = lb === ub ? glpk.GLP_FX : !Number.isFinite(lb) ? glpk.GLP_UP : !Number.isFinite(ub) ? glpk.GLP_LO : glpk.GLP_DB;
    rows.push({ name: `r${rows.length}`, vars: [...combined].filter(([, coef]) => coef !== 0).map(([name, coef]) => ({ name, coef })), bnds: { type, lb: Number.isFinite(lb) ? lb : 0, ub: Number.isFinite(ub) ? ub : 0 } });
  }
  const starts = dag.nodes.map(() => variable('start', false)), cmax = variable('T', false);
  const y = dag.nodes.map(() => Array.from({ length: K }, () => variable('host')));
  dag.nodes.forEach((node, i) => { row(y[i].map(v => [v, 1]), 1, 1); row([[starts[i], 1], [cmax, -1]], -Infinity, -node.duration); });
  row([[y[0][0], 1]], 1, 1); // Only removes interchangeable host labels.
  for (let i = 0; i < dag.nodes.length; i++) for (let j = i + 1; j < dag.nodes.length; j++) {
    const order = variable('cpu_order');
    for (let k = 0; k < K; k++) {
      row([[starts[i], 1], [starts[j], -1], [y[i][k], B], [y[j][k], B], [order, B]], -Infinity, 3 * B - dag.nodes[i].duration);
      row([[starts[j], 1], [starts[i], -1], [y[i][k], B], [y[j][k], B], [order, -B]], -Infinity, 2 * B - dag.nodes[j].duration);
    }
  }
  const active = [], transfer = [], channels = [];
  dag.edges.forEach(edge => {
    const i = index.get(edge.source), j = index.get(edge.target), q = edge.duration;
    const a = variable('active'), t = variable('transfer', false), same = Array.from({ length: K }, () => variable('same'));
    active.push(a); transfer.push(t);
    same.forEach((w, k) => { row([[w, 1], [y[i][k], -1]], -Infinity, 0); row([[w, 1], [y[j][k], -1]], -Infinity, 0); row([[w, 1], [y[i][k], -1], [y[j][k], -1]], -1); });
    row([[a, 1], ...same.map(w => [w, 1])], 1, 1);
    const z = Array.from({ length: C }, () => variable('channel')); channels.push(z);
    row([...z.map(v => [v, 1]), [a, -1]], 0, 0);
    row([[t, 1], [a, -B]], -Infinity, 0);
    row([[t, 1], [a, q]], -Infinity, B);
    row([[starts[i], 1], [starts[j], -1]], -Infinity, -dag.nodes[i].duration);
    row([[starts[i], 1], [t, -1], [a, B]], -Infinity, B - dag.nodes[i].duration);
    row([[t, 1], [a, q], [starts[j], -1]], -Infinity, 0);
  });
  const positive = dag.edges.map((e, i) => e.duration > 0 ? i : -1).filter(i => i >= 0);
  for (let ei = 0; ei < positive.length; ei++) for (let fi = ei + 1; fi < positive.length; fi++) {
    const e = positive[ei], f = positive[fi], order = variable('net_order');
    for (let c = 0; c < C; c++) {
      row([[transfer[e], 1], [transfer[f], -1], [active[e], dag.edges[e].duration], [channels[e][c], B], [channels[f][c], B], [order, B]], -Infinity, 3 * B);
      row([[transfer[f], 1], [transfer[e], -1], [active[f], dag.edges[f].duration], [channels[e][c], B], [channels[f][c], B], [order, -B]], -Infinity, 2 * B);
    }
  }
  const model = { name: 'care_reserve_continuous', objective: { direction: glpk.GLP_MIN, name: 'makespan', vars: [{ name: cmax, coef: 1 }] }, subjectTo: rows, bounds, binaries };
  const remaining = cfg.milpTimeLimit - (now() - started) / 1000;
  if (remaining <= 0.001) return fallback('The time budget was used preparing the feasible seed and MILP; returned the validated heuristic.', '可行初始解和 MILP 构建已用完预算；返回已验证的启发式方案。');
  let solution;
  try { solution = await glpk.solve(model, { msglev: glpk.GLP_MSG_OFF, presol: true, tmlim: remaining, mipgap: 0 }); }
  catch (error) { return fallback(`GLPK failed (${error.message}); returned the validated heuristic.`, 'GLPK 求解失败；返回已验证的启发式方案。', true); }
  const status = solution?.result?.status, vars = solution?.result?.vars;
  if (![glpk.GLP_OPT, glpk.GLP_FEAS].includes(status) || !vars) return fallback('GLPK produced no validated incumbent within the budget; returned the CARE Reserve heuristic. No optimality claim.', 'GLPK 未在预算内获得可验证的可行解；返回 CARE 预留启发式方案，无最优证明。', true, { solver_status: status });
  function selected(names) {
    if (names.some(n => !Number.isFinite(vars[n]))) throw new Error('Missing solver assignment.');
    return names.reduce((best, n, i) => vars[n] > vars[names[best]] ? i : best, 0);
  }
  let candidate;
  try {
    const tasks = dag.nodes.map((node, i) => {
      const resource = selected(y[i]), start = Math.max(0, vars[starts[i]]);
      return { id: node.id, resource, start, end: start + node.duration };
    });
    const flows = [];
    dag.edges.forEach((edge, e) => {
      if (!Number.isFinite(vars[active[e]])) throw new Error('Missing transfer activation.');
      if (vars[active[e]] > 0.5) { const start = Math.max(0, vars[transfer[e]]); flows.push({ source: edge.source, target: edge.target, resource: selected(channels[e]), start, end: start + edge.duration }); }
    });
    candidate = { tasks, flows, completion_time: Math.max(...tasks.map(t => t.end)) };
    validateSchedule(dag, candidate);
    if (candidate.completion_time > B + EPS) throw new Error('Solver incumbent exceeds its feasible upper bound.');
  } catch (error) { return fallback(`GLPK output failed physical validation (${error.message}); returned the validated heuristic.`, 'GLPK 输出未通过物理约束验证；返回已验证的启发式方案。', true, { solver_status: status }); }
  const optimal = status === glpk.GLP_OPT;
  const best = candidate.completion_time <= seed.completion_time + EPS ? candidate : seed;
  return finish(best, { status: optimal ? 'optimal' : 'feasible', optimal, solver_ran: true, solver_status: status, solver_gap: optimal ? 0 : null, lower_bound: optimal ? candidate.completion_time : null, carbon_optimal: optimal, note: optimal ? 'GLPK proved global minimum makespan within numerical tolerances.' : 'Validated GLPK incumbent; time-limited, global optimality is not proved.', note_zh: optimal ? 'GLPK 在数值容差内证明了全局最短完成时间。' : '已验证 GLPK 可行解；求解限时，未证明全局最优。' });
}
