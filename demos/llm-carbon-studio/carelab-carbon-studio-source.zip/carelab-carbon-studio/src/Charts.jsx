import React from 'react';
import {ledgerAt} from './engine.js';
const COLORS=['#5fc9ba','#73a7ff','#e1b969','#b298e9','#e48d9a','#73c2df','#b1c47a','#de9a6f'];
export const taskColor=(id,dag)=>COLORS[(dag?Math.max(0,dag.nodes.findIndex(n=>n.id===id)):Number(id))%COLORS.length];
export const num=(v,n=2)=>Number.isFinite(v)?Number(v).toFixed(n):'—';
function ticks(max,n=6){const raw=Math.max(.0001,max/n),base=10**Math.floor(Math.log10(raw)),step=[1,2,5,10].find(k=>k*base>=raw)*base;return Array.from({length:Math.floor(max/step)+1},(_,i)=>+(i*step).toFixed(6));}
export function Gantt({dag,result,time,maxTime,lang,onSeek}){
 const lanes=dag.resources.servers+dag.resources.channels, W=640,L=55,R=16,H=lanes*25+32,scale=(W-L-R)/maxTime,t=Math.min(time,result.completion_time),zh=lang==='zh';
 const records=[...result.tasks.map(x=>({...x,row:x.resource,label:`T${x.id}`,col:taskColor(x.id,dag)})),...result.flows.filter(x=>x.end>x.start).map(x=>({...x,row:dag.resources.servers+x.resource,label:`${x.source}→${x.target}`,col:taskColor(x.target,dag)}))];
 return <svg className="gantt" viewBox={`0 0 ${W} ${H}`} role="img" aria-label={zh?'计算与网络甘特图，点击可定位时间':'Compute and network Gantt, click to seek'} onClick={e=>{const b=e.currentTarget.getBoundingClientRect(),x=(e.clientX-b.left)/b.width*W;onSeek?.(Math.max(0,Math.min(maxTime,(x-L)/scale)));}}>
  {Array.from({length:lanes},(_,i)=><g key={i}><text x="2" y={i*25+17} className="axis-label">{i<dag.resources.servers?`VM${i+1}`:`CH${i-dag.resources.servers+1}`}</text><rect x={L} y={i*25+3} width={result.completion_time*scale} height="20" rx="2" fill="#172c39"/></g>)}
  {ticks(maxTime).map(v=><g key={v}><line x1={L+v*scale} x2={L+v*scale} y1="0" y2={H-22} stroke="#2b3e4d" strokeDasharray="2 4"/><text x={L+v*scale} y={H-6} textAnchor="middle" className="axis-label">{v}</text></g>)}
  {records.map((r,i)=><g key={i}><rect x={L+r.start*scale} y={r.row*25+3} width={Math.max(.4,(r.end-r.start)*scale)} height="20" rx="3" fill={r.col} opacity={r.start>=t?.28:.92}/>{t>r.start&&t<r.end&&<rect x={L+t*scale} y={r.row*25+3} width={(r.end-t)*scale} height="20" fill="#08131e" opacity=".6"/>}{(r.end-r.start)*scale>19&&<text x={L+(r.start+r.end)/2*scale} y={r.row*25+17} textAnchor="middle" className="task-label">{r.label}</text>}<title>{r.label} · {num(r.start)}–{num(r.end)} tu</title></g>)}
  <line x1={L+t*scale} x2={L+t*scale} y1="0" y2={H-23} stroke="#f9d284" strokeWidth="2"/>
  <text x={W-1} y={H-6} textAnchor="end" className="axis-label">tu</text>
 </svg>;
}
export function CarbonCurve({dag,result,config,time,maxTime,maxCarbon,lang}){
 const W=640,H=111,L=55,R=16,top=9,bottom=86,dx=(W-L-R)/maxTime,dy=(bottom-top)/Math.max(maxCarbon,.00001);
 const all=Array.from(new Set([0,result.completion_time,...result.tasks.flatMap(x=>[x.start,x.end])])).sort((a,b)=>a-b);
 const clamp=Math.min(time,result.completion_time),points=[...all.filter(x=>x<clamp),clamp],full=[...all,maxTime];
 const path=arr=>arr.map((x,i)=>`${i?'L':'M'}${L+x*dx},${bottom-ledgerAt(dag,result,config,x).totalG*dy}`).join(' ');
 return <svg className="carbon-curve" viewBox={`0 0 ${W} ${H}`} role="img" aria-label={lang==='zh'?'累计碳排放随时间变化':'Cumulative operational carbon over time'}>
  {[0,.5,1].map(a=><g key={a}><line x1={L} x2={W-R} y1={bottom-(bottom-top)*a} y2={bottom-(bottom-top)*a} stroke="#20333f" strokeDasharray="2 4"/><text x={L-8} y={bottom-(bottom-top)*a+4} textAnchor="end" className="axis-label">{num(maxCarbon*a,2)}</text></g>)}
  <path d={path(full)} fill="none" stroke="#60dbc2" strokeWidth="1.3" opacity=".2" strokeDasharray="4 4"/>
  <path d={`${path(points)} L${L+clamp*dx},${bottom} L${L},${bottom} Z`} fill="#58cfb5" opacity=".08"/>
  <path d={path(points)} fill="none" stroke="#66e3c4" strokeWidth="2.5"/>
  <line x1={L+clamp*dx} x2={L+clamp*dx} y1={top} y2={bottom} stroke="#f9d284" strokeDasharray="3 3"/>
  <circle cx={L+clamp*dx} cy={bottom-ledgerAt(dag,result,config,clamp).totalG*dy} r="3.5" fill="#b9ffeb"/>
  <text x={L} y="105" className="axis-label">0</text><text x={W-R} y="105" textAnchor="end" className="axis-label">{num(maxTime,1)} tu</text>
 </svg>;
}
export function Breakdown({ledger,config,lang}){
 const factor=config.pue*config.ci/3600000,idle=ledger.servers.reduce((a,s)=>a+(s.busySeconds+s.idleSeconds)*config.idleW*factor,0),active=ledger.servers.reduce((a,s)=>a+s.busySeconds*(config.busyW-config.idleW)*factor,0),network=ledger.network.carbonG,total=Math.max(ledger.totalG,1e-12),zh=lang==='zh';
 const items=[[zh?'计算增量':'Compute',active,'#67d8c1'],[zh?'VM 基础功耗':'VM baseline',idle,'#749fdb'],[zh?'网络预留':'Network',network,'#c4a2e9']];
 return <div className="breakdown"><div className="stacked-bar">{items.map(([name,v,col])=><span key={name} style={{width:`${v/total*100}%`,background:col}} title={`${name}: ${num(v,4)} gCO₂e`}/>)}</div><div className="breakdown-values">{items.map(([name,v,col])=><span key={name}><i style={{background:col}}/>{name}<b>{num(v,3)}</b></span>)}</div></div>;
}
