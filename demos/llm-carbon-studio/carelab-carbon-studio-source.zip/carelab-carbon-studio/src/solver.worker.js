import GLPK from 'glpk.js';
import { METHODS, normalizeInput, solveHeuristic, solveMilp, validateSchedule } from './engine.js';

let solverPromise;
self.onmessage = async ({ data }) => {
  const { id, config = {}, methods = METHODS.map(method => method.id) } = data;
  try {
    if (!Array.isArray(methods) || !methods.length || new Set(methods).size !== methods.length || methods.some(method => !METHODS.some(m => m.id === method))) throw new Error('Choose valid, unique scheduling methods.');
    const dag = normalizeInput(data.dag, config);
    for (let index = 0; index < methods.length; index++) {
      const method = methods[index];
      self.postMessage({ type: 'progress', id, method, index, total: methods.length });
      let result;
      if (method === 'milp') {
        let solver;
        try { solverPromise ||= GLPK(); solver = await solverPromise; } catch { solverPromise = null; }
        result = await solveMilp(dag, config, solver);
      } else result = solveHeuristic(dag, method);
      validateSchedule(dag, result);
      self.postMessage({ type: 'result', id, result });
    }
    self.postMessage({ type: 'done', id });
  } catch (error) {
    self.postMessage({ type: 'error', id, message: error.message });
  }
};
