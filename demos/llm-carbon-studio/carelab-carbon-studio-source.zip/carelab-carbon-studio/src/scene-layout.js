/** A compact topological layout; long chains wrap instead of shrinking labels. */
export function layoutDag(dag = {}) {
  const nodes = dag.nodes || [];
  const byId = new Map(nodes.map((node, index) => [String(node.id), index]));
  const incoming = nodes.map(() => 0);
  const outgoing = nodes.map(() => []);
  for (const edge of dag.edges || []) {
    const from = byId.get(String(edge.source));
    const to = byId.get(String(edge.target));
    if (from !== undefined && to !== undefined) {
      incoming[to]++;
      outgoing[from].push(to);
    }
  }
  const degree = incoming.slice();
  const rank = nodes.map(() => 0);
  const queue = nodes.map((_, index) => index).filter(index => degree[index] === 0);
  const order = [];
  for (let head = 0; head < queue.length; head++) {
    const index = queue[head];
    order.push(index);
    for (const next of outgoing[index]) {
      rank[next] = Math.max(rank[next], rank[index] + 1);
      if (--degree[next] === 0) queue.push(next);
    }
  }
  // Invalid/cyclic input remains inspectable while the scheduler reports its error.
  nodes.forEach((_, index) => { if (!order.includes(index)) order.push(index); });
  const layers = [];
  order.forEach(index => (layers[rank[index]] ||= []).push(index));
  const maxLayerWidth = Math.max(0, ...layers.map(layer => layer?.length || 0));
  const compact = layers.length <= 7 && maxLayerWidth <= 6;
  const positions = new Map();
  if (compact) {
    const columns = Math.max(1, layers.length);
    layers.forEach((layer = [], column) => {
      const top = layer.length === 6 ? 10 : 8.75;
      const span = layer.length === 6 ? 5.75 : 4.1;
      layer.forEach((index, row) => {
        positions.set(String(nodes[index].id), {
          x: columns === 1 ? 0 : (column / (columns - 1) - .5) * 11.2,
          y: layer.length === 1 ? maxLayerWidth === 6 ? 7.125 : 6.55 : top - row / (layer.length - 1) * span,
          z: -.55,
          rank: column,
        });
      });
    });
  } else {
    const columns = Math.min(7, Math.max(2, Math.ceil(Math.sqrt(nodes.length * 1.65))));
    const rows = Math.ceil(nodes.length / columns);
    order.forEach((index, ordinal) => {
      const row = Math.floor(ordinal / columns);
      const column = row % 2 ? columns - 1 - ordinal % columns : ordinal % columns;
      positions.set(String(nodes[index].id), {
        x: (column / Math.max(1, columns - 1) - .5) * 11.2,
        y: rows === 1 ? 6.55 : 8.75 - row / (rows - 1) * 4.1,
        z: -.55,
        rank: rank[index],
      });
    });
  }
  return positions;
}

export function serverLayout(count) {
  if (count === 1) return [{x: 0, z: 2.4}];
  if (count === 2) return [{x: -3.9, z: 1.5}, {x: 3.9, z: 1.5}];
  if (count === 3) return [{x: -4.3, z: 2}, {x: 0, z: -2.1}, {x: 4.3, z: 2}];
  const front = Math.ceil(count / 2);
  const back = count - front;
  return Array.from({length: count}, (_, index) => {
    const isFront = index < front;
    const width = isFront ? front : back;
    const column = isFront ? index : index - front;
    return {x: width === 1 ? 0 : (column / (width - 1) - .5) * 9.8, z: isFront ? 2.65 : -2.3};
  });
}
