import React, {useEffect, useRef, useState} from 'react';

// A second native scrollbar, kept in sync with the method panels. It is
// available at the viewport edge even when the Gantt charts extend below it.
export default function ComparisonScrollbar({targetRef, layoutKey, lang}) {
 const bar = useRef(null);
 const [size,setSize] = useState({left:0,width:0,content:0,visible:false});
 useEffect(()=>{
  const target=targetRef.current, dock=bar.current;
  if(!target||!dock)return;
  const measure=()=>{
   const rect=target.getBoundingClientRect();
   setSize({left:rect.left,width:rect.width,content:target.scrollWidth,visible:target.scrollWidth>target.clientWidth+2});
   if(Math.abs(dock.scrollLeft-target.scrollLeft)>1)dock.scrollLeft=target.scrollLeft;
  };
  const followTarget=()=>{if(Math.abs(dock.scrollLeft-target.scrollLeft)>1)dock.scrollLeft=target.scrollLeft;};
  const followDock=()=>{if(Math.abs(target.scrollLeft-dock.scrollLeft)>1)target.scrollLeft=dock.scrollLeft;};
  const observer=new ResizeObserver(measure);
  observer.observe(target);
  target.addEventListener('scroll',followTarget,{passive:true});
  dock.addEventListener('scroll',followDock,{passive:true});
  window.addEventListener('resize',measure);
  measure();
  return()=>{observer.disconnect();target.removeEventListener('scroll',followTarget);dock.removeEventListener('scroll',followDock);window.removeEventListener('resize',measure);};
 },[targetRef,layoutKey]);
 return <div ref={bar} className="comparison-scrollbar" tabIndex={size.visible?0:-1} role="region" aria-label={lang==='zh'?'左右滚动调度方法':'Scroll scheduling methods horizontally'} title={lang==='zh'?'拖动底部滚动条，对照不同方法':'Drag to compare scheduling methods'} style={{left:size.left,width:size.width,visibility:size.visible?'visible':'hidden'}}><div style={{width:size.content,height:1}}/></div>;
}
