import React from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.jsx';
import AccessGate from './AccessGate.jsx';
import './styles.css';
createRoot(document.getElementById('root')).render(<AccessGate><App/></AccessGate>);
