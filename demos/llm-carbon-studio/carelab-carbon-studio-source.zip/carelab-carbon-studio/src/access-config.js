// Public salted verifier for a temporary demonstration gate. Not server authentication.
export const ACCESS_CONFIG = Object.freeze({
  "enabled": true,
  "version": 1,
  "algorithm": "PBKDF2",
  "digest": "SHA-256",
  "iterations": 600000,
  "salt": "QLlJi47NDSlO2ALwLcmpp+k2CEOExMri",
  "verifier": "DGfIgDofmqXKrrsQPH0Mup/bzco0u+iEN4N8Qzv2SLM="
});
