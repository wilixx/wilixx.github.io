import { ACCESS_CONFIG } from './access-config.js';

export { ACCESS_CONFIG };
export const PASSWORD_MIN_LENGTH = 6;
export const PASSWORD_MAX_LENGTH = 256;
export const DEFAULT_ITERATIONS = 600000;

function cryptography() {
  if (!globalThis.crypto?.subtle || !globalThis.crypto?.getRandomValues) {
    throw new Error('Password verification requires Web Crypto on HTTPS or localhost.');
  }
  return globalThis.crypto;
}

function encodeBase64(bytes) {
  return btoa(String.fromCharCode(...bytes));
}

function decodeBase64(value, name) {
  if (typeof value !== 'string' || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value) || value.length > 128) {
    throw new Error(`Invalid access configuration: ${name}.`);
  }
  const bytes = Uint8Array.from(atob(value), char => char.charCodeAt(0));
  if (encodeBase64(bytes) !== value) throw new Error(`Invalid access configuration: ${name}.`);
  return bytes;
}

export function validAccessPassword(password) {
  return typeof password === 'string' && password.length >= PASSWORD_MIN_LENGTH && password.length <= PASSWORD_MAX_LENGTH;
}

export function validateAccessConfig(config) {
  if (!config || typeof config !== 'object' || typeof config.enabled !== 'boolean' || config.version !== 1 || config.algorithm !== 'PBKDF2' || config.digest !== 'SHA-256') {
    throw new Error('Invalid access configuration: unsupported format.');
  }
  if (!Number.isInteger(config.iterations) || config.iterations < 100000 || config.iterations > 2000000) {
    throw new Error('Invalid access configuration: iteration count.');
  }
  const salt = decodeBase64(config.salt, 'salt');
  const verifier = decodeBase64(config.verifier, 'verifier');
  if (salt.length < 16 || salt.length > 64 || verifier.length !== 32) {
    throw new Error('Invalid access configuration: salt or verifier length.');
  }
  return { salt, verifier };
}

async function derive(password, salt, iterations) {
  const crypto = cryptography();
  const encoded = new TextEncoder().encode(password);
  let key;
  try {
    key = await crypto.subtle.importKey('raw', encoded, 'PBKDF2', false, ['deriveBits']);
  } finally {
    encoded.fill(0);
  }
  return new Uint8Array(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, key, 256));
}

// No cookies, storage, or reusable unlock token: the caller keeps unlock state in memory.
// A public client-side gate discourages casual access; it cannot protect source or data.
export async function verifyAccessPassword(password, config = ACCESS_CONFIG) {
  const { salt, verifier } = validateAccessConfig(config);
  if (!validAccessPassword(password)) return false;
  const actual = await derive(password, salt, config.iterations);
  let difference = 0;
  for (let index = 0; index < verifier.length; index++) difference |= actual[index] ^ verifier[index];
  actual.fill(0);
  return difference === 0;
}

export async function createAccessConfig(password, { iterations = DEFAULT_ITERATIONS } = {}) {
  if (!validAccessPassword(password)) throw new Error(`Use ${PASSWORD_MIN_LENGTH}–${PASSWORD_MAX_LENGTH} characters for the demonstration password.`);
  if (!Number.isInteger(iterations) || iterations < 100000 || iterations > 2000000) throw new Error('Invalid access configuration: iteration count.');
  const salt = cryptography().getRandomValues(new Uint8Array(24));
  const verifier = await derive(password, salt, iterations);
  return Object.freeze({ enabled: true, version: 1, algorithm: 'PBKDF2', digest: 'SHA-256', iterations, salt: encodeBase64(salt), verifier: encodeBase64(verifier) });
}
