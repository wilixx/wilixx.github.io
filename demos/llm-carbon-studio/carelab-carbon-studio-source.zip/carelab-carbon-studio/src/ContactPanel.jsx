import React, { useEffect, useRef, useState } from 'react';
import { ArrowUpRight, Github, Mail } from 'lucide-react';
import './contact.css';

const profiles = [
  { label: 'IEEE', href: 'https://ieeexplore.ieee.org/author/37089678912' },
  { label: 'Google Scholar', href: 'https://scholar.google.com/citations?user=NA8egm4AAAAJ&hl=en' },
  { label: 'GitHub', href: 'https://github.com/wilixx' },
];
const qrUrl = `${import.meta.env.BASE_URL}wechat-academic.png`;
const linkedInUrl = 'https://www.linkedin.com/in/binquan-guo-754078371/';

function WeChatIcon() {
  return <svg className="studio-wechat-icon" width="20" height="20" viewBox="0 0 28 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M11 1C5.5 1 1 4.5 1 8.8c0 2.4 1.4 4.5 3.6 5.9l-.9 3.1 3.8-1.9c.8.2 1.7.4 2.6.5a7.5 7.5 0 0 1-.5-2.7c0-4.6 4.4-8.3 9.8-8.3h.6C18.4 2.8 15 1 11 1Zm-3.2 4a1.3 1.3 0 1 1 0 2.6 1.3 1.3 0 0 1 0-2.6Zm6.5 0a1.3 1.3 0 1 1 0 2.6 1.3 1.3 0 0 1 0-2.6Z"/><path fill="currentColor" d="M19.4 7C14.8 7 11 10 11 13.7s3.8 6.7 8.4 6.7c1.1 0 2.2-.2 3.2-.5l3.1 1.6-.7-2.7c1.8-1.2 2.8-3 2.8-5.1C27.8 10 24 7 19.4 7Zm-2.8 3.7a1.1 1.1 0 1 1 0 2.2 1.1 1.1 0 0 1 0-2.2Zm5.6 0a1.1 1.1 0 1 1 0 2.2 1.1 1.1 0 0 1 0-2.2Z"/></svg>;
}

export default function ContactPanel({ lang = 'en' }) {
  const zh = lang === 'zh';
  const dialog = useRef(null);
  const trigger = useRef(null);
  const closeButton = useRef(null);
  const closeTimer = useRef(null);
  const pressedBackdrop = useRef(false);
  const [closing, setClosing] = useState(false);
  const [opened, setOpened] = useState(false);

  useEffect(() => () => window.clearTimeout(closeTimer.current), []);
  const finishClose = () => {
    window.clearTimeout(closeTimer.current);
    dialog.current?.close();
  };
  const requestClose = () => {
    if (!dialog.current?.open || closing) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return finishClose();
    setClosing(true);
    closeTimer.current = window.setTimeout(finishClose, 240);
  };
  const open = () => {
    if (!dialog.current || dialog.current.open) return;
    window.clearTimeout(closeTimer.current);
    setClosing(false);
    pressedBackdrop.current = false;
    dialog.current.showModal();
    setOpened(true);
    closeButton.current?.focus({ preventScroll: true });
  };
  const outside = event => {
    const bounds = dialog.current.getBoundingClientRect();
    return event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom;
  };
  const closed = () => {
    window.clearTimeout(closeTimer.current);
    setClosing(false);
    setOpened(false);
    pressedBackdrop.current = false;
    trigger.current?.focus({ preventScroll: true });
  };

  return <section className="studio-contact" aria-label={zh ? '学术主页与联系' : 'Academic profiles and contact'}>
    <div className="studio-contact-name"><span>Binquan Guo</span><button className="studio-contact-trigger" ref={trigger} type="button" onClick={open} title={zh ? '微信' : 'WeChat'} aria-label={zh ? '通过微信联系' : 'Connect on WeChat'} aria-haspopup="dialog" aria-controls="studio-contact-dialog" aria-expanded={opened}><WeChatIcon/></button></div>
    <nav className="studio-profile-links" aria-label={zh ? '学术主页' : 'Academic profiles'}>{profiles.map(profile => <a key={profile.label} href={profile.href} target="_blank" rel="noopener noreferrer">{profile.label === 'GitHub' && <Github size={11} aria-hidden="true"/>}{profile.label}<ArrowUpRight size={10} aria-hidden="true"/></a>)}</nav>
    <a className="studio-contact-email" href="mailto:bqguo@stu.xidian.edu.cn"><Mail size={11} aria-hidden="true"/><span>bqguo@stu.xidian.edu.cn</span></a>
    <dialog className={`studio-contact-dialog${closing ? ' is-closing' : ''}`} id="studio-contact-dialog" ref={dialog} aria-labelledby="studio-contact-title" aria-describedby="studio-contact-hint"
      onCancel={event => { event.preventDefault(); requestClose(); }} onClose={closed}
      onPointerDown={event => { pressedBackdrop.current = event.target === dialog.current && outside(event); }}
      onPointerCancel={() => { pressedBackdrop.current = false; }}
      onClick={event => { if (pressedBackdrop.current && event.target === dialog.current && outside(event)) requestClose(); pressedBackdrop.current = false; }}
      onAnimationEnd={event => { if (event.target === dialog.current && event.animationName === 'studio-contact-out') finishClose(); }}>
      <button className="studio-contact-close" ref={closeButton} type="button" onClick={requestClose} aria-label={zh ? '关闭联系方式' : 'Close contact dialog'}>×</button>
      <h2 id="studio-contact-title"><WeChatIcon/><span>{zh ? '微信' : 'WeChat'}</span></h2>
      <p id="studio-contact-hint">{zh ? '扫描二维码，交流联系。' : 'Scan the QR code to connect.'}</p>
      <img className="studio-contact-qr" src={qrUrl} alt={zh ? 'Binquan Guo 的微信联系二维码' : "Binquan Guo's WeChat contact QR code"} width="410" height="410" loading="lazy" decoding="async"/>
      <div className="studio-contact-actions"><a href={qrUrl} download="binquan-guo-wechat.png">{zh ? '保存二维码' : 'Save QR code'}</a><a className="studio-contact-linkedin" href={linkedInUrl} target="_blank" rel="noopener noreferrer" aria-label={zh ? '在新标签页打开 LinkedIn 主页' : 'Open LinkedIn profile in a new tab'}>LinkedIn <ArrowUpRight size={12} aria-hidden="true"/></a></div>
    </dialog>
  </section>;
}
