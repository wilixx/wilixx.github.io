/** Browser-only recording. No microphone, upload, or server conversion. */
export const RECORDING_MAX_BYTES = 200 * 1024 * 1024;
export const RECORDING_MAX_MS = 10 * 60 * 1000;

export function recordingFormat(supported) {
  return [
    'video/mp4;codecs=avc1.42E028',
    'video/mp4;codecs=avc1',
    'video/mp4',
    'video/webm;codecs=h264',
    'video/webm;codecs=vp8',
    'video/webm',
  ].find(type => supported(type)) || '';
}

export function recordingFilename(mime, date = new Date()) {
  const extension = mime.toLowerCase().startsWith('video/mp4') ? 'mp4' : 'webm';
  return `CARELab-Carbon-Studio-${date.toISOString().replace(/[:.]/g, '-')}.${extension}`;
}

// Do not trust a MIME label or silently rename WebM as MP4. Both the direct
// recorder output and the converted output must contain an ISO BMFF ftyp box.
export async function isMp4Blob(blob) {
  const bytes = new Uint8Array(await blob.slice(0, 4096).arrayBuffer());
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  for (let offset = 0; offset + 12 <= bytes.length;) {
    const size = view.getUint32(offset);
    const type = String.fromCharCode(...bytes.slice(offset + 4, offset + 8));
    if (type === 'ftyp' && size >= 16 && offset + 16 <= bytes.length) return true;
    if (size < 8 || size > bytes.length - offset) break;
    offset += size;
  }
  return false;
}

/** Isolated so clocks, pause/resume and stream cleanup can be tested without
 * desktop screen access. MediaRecorder itself owns the actual video frames. */
export class CaptureSession {
  constructor(stream, mime, bits = 5000000, changed = () => {}, options = {}) {
    const Recorder = options.Recorder || globalThis.MediaRecorder;
    this.now = options.now || (() => performance.now());
    this.maxBytes = options.maxBytes || RECORDING_MAX_BYTES;
    this.stream = stream;
    this.changed = changed;
    this.bytes = 0;
    this.chunks = [];
    this.elapsed = 0;
    this.since = null;
    this.reason = '';
    this.state = 'idle';
    this.settled = false;
    this.recorder = new Recorder(stream, { mimeType: mime, videoBitsPerSecond: bits });
    this.done = new Promise((resolve, reject) => { this.resolve = resolve; this.reject = reject; });
    // A synchronous recorder.start() failure may precede the caller's await.
    this.done.catch(() => {});
    this.onEnded = () => this.stop('sharing-ended');
    this.stream.getVideoTracks().forEach(track => track.addEventListener('ended', this.onEnded));
    this.recorder.ondataavailable = event => {
      if (this.settled || !event.data?.size) return;
      this.chunks.push(event.data);
      this.bytes += event.data.size;
      this.changed();
      if (this.bytes >= this.maxBytes) this.stop('limit');
    };
    this.recorder.onerror = () => {
      // The Recording spec emits a final dataavailable and stop after error.
      // Wait for those events instead of dropping the last received chunk.
      this.reason ||= 'encoder';
      this.freezeClock();
      this.state = 'stopping';
      this.changed();
    };
    this.recorder.onstop = () => this.finish(mime);
  }

  freezeClock() {
    if (this.since !== null) this.elapsed += Math.max(0, this.now() - this.since);
    this.since = null;
  }
  duration() {
    return this.elapsed + (this.since === null ? 0 : Math.max(0, this.now() - this.since));
  }
  start() {
    if (this.state !== 'idle') return;
    try {
      this.recorder.start(1000);
      this.state = 'recording';
      this.since = this.now();
      this.changed();
    } catch (error) {
      this.cleanup();
      this.state = 'stopped';
      this.settled = true;
      this.reject(error);
      throw error;
    }
  }
  pause() {
    if (this.state !== 'recording') return;
    this.recorder.pause();
    this.freezeClock();
    this.state = 'paused';
    this.changed();
  }
  resume() {
    if (this.state !== 'paused') return;
    this.recorder.resume();
    this.since = this.now();
    this.state = 'recording';
    this.changed();
  }
  stop(reason = '') {
    if (this.settled || this.state === 'stopping') return;
    this.reason ||= reason;
    this.freezeClock();
    this.state = 'stopping';
    if (this.recorder.state !== 'inactive') {
      try { this.recorder.stop(); } catch { this.finish(this.recorder.mimeType); }
    } else {
      // Includes encoder failure before recording begins. In the usual path,
      // onstop follows the final dataavailable event and settles the promise.
      this.finish(this.recorder.mimeType);
    }
    this.changed();
  }
  cleanup() {
    this.stream.getVideoTracks().forEach(track => track.removeEventListener('ended', this.onEnded));
    this.stream.getTracks().forEach(track => track.stop());
  }
  finish(mime) {
    if (this.settled) return;
    this.settled = true;
    this.freezeClock();
    this.cleanup();
    this.state = 'stopped';
    const blob = new Blob(this.chunks, { type: this.recorder.mimeType || mime });
    this.chunks = [];
    this.changed();
    if (!blob.size) this.reject(new Error('empty'));
    else this.resolve({ blob, duration: this.elapsed, reason: this.reason });
  }
}

/** Mediabunny loads only for browsers that cannot record MP4 directly. It
 * transmuxes H.264 where possible and otherwise really encodes H.264 using
 * WebCodecs. An unsupported encoder is reported, never disguised as MP4.
 * Reference: https://mediabunny.dev/guide/converting-media-files */
export async function makeMp4(blob, { onProgress = () => {}, signal, load = () => import('mediabunny') } = {}) {
  const aborted = () => { if (signal?.aborted) throw new DOMException('Conversion canceled', 'AbortError'); };
  aborted();
  if (await isMp4Blob(blob)) {
    onProgress(1);
    return blob.type === 'video/mp4' ? blob : new Blob([blob], { type: 'video/mp4' });
  }
  const { Input, Output, Conversion, ALL_FORMATS, BlobSource, BufferTarget, Mp4OutputFormat } = await load();
  aborted();
  const input = new Input({ formats: ALL_FORMATS, source: new BlobSource(blob) });
  const output = new Output({ format: new Mp4OutputFormat(), target: new BufferTarget() });
  let conversion;
  const cancel = () => { conversion?.cancel().catch(() => {}); };
  try {
    conversion = await Conversion.init({ input, output, video: { codec: 'avc' }, audio: { discard: true } });
    aborted();
    if (!conversion.isValid) throw new Error('mp4-unsupported');
    signal?.addEventListener('abort', cancel, { once: true });
    conversion.onProgress = progress => onProgress(Math.max(0, Math.min(1, progress)));
    await conversion.execute();
    aborted();
    const result = new Blob([output.target.buffer], { type: 'video/mp4' });
    if (!(await isMp4Blob(result))) throw new Error('invalid-mp4');
    onProgress(1);
    return result;
  } catch (error) {
    if (conversion) await conversion.cancel().catch(() => {});
    throw error;
  } finally {
    signal?.removeEventListener('abort', cancel);
    input.dispose();
  }
}
