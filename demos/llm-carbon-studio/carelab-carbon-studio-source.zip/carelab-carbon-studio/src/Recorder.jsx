import { useEffect, useRef, useState } from 'react';
import { Video, Circle, Pause, Play, Square, Download, X, LoaderCircle, RotateCcw } from 'lucide-react';
import { CaptureSession, RECORDING_MAX_MS, makeMp4, recordingFilename, recordingFormat } from './recording.js';
import './recorder.css';

const clock = seconds => `${Math.floor(seconds / 60).toString().padStart(2, '0')}:${Math.floor(seconds % 60).toString().padStart(2, '0')}`;

export default function Recorder({ lang = 'en' }) {
  const zh = lang === 'zh', t = (cn, en) => zh ? cn : en;
  const [open, setOpen] = useState(false), [phase, setPhase] = useState('idle');
  const [seconds, setSeconds] = useState(0), [bytes, setBytes] = useState(0);
  const [quality, setQuality] = useState('1080'), [progress, setProgress] = useState(0);
  const [notice, setNotice] = useState(''), [result, setResult] = useState(null), [saved, setSaved] = useState(false);
  const shell = useRef(null), session = useRef(null), mounted = useRef(true), conversion = useRef(null), urls = useRef([]), starting = useRef(false);
  const supported = !!globalThis.navigator?.mediaDevices?.getDisplayMedia && typeof MediaRecorder !== 'undefined';
  const mime = supported ? recordingFormat(type => MediaRecorder.isTypeSupported(type)) : '';
  const active = phase === 'recording' || phase === 'paused', locked = phase !== 'idle';

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      conversion.current?.abort();
      session.current?.stop();
      session.current?.stream.getTracks().forEach(track => track.stop());
      urls.current.forEach(url => URL.revokeObjectURL(url));
    };
  }, []);
  useEffect(() => {
    if (!open) return;
    const outside = event => { if (!shell.current?.contains(event.target)) setOpen(false); };
    const escape = event => { if (event.key === 'Escape') setOpen(false); };
    document.addEventListener('pointerdown', outside);
    document.addEventListener('keydown', escape);
    return () => { document.removeEventListener('pointerdown', outside); document.removeEventListener('keydown', escape); };
  }, [open]);
  useEffect(() => {
    if (!active) return;
    const interval = setInterval(() => {
      const current = session.current;
      if (!current) return;
      setSeconds(current.duration() / 1000);
      if (current.duration() >= RECORDING_MAX_MS) current.stop('limit');
    }, 200);
    return () => clearInterval(interval);
  }, [active]);
  useEffect(() => {
    if (!locked && (!result || saved)) return;
    const before = event => { event.preventDefault(); event.returnValue = ''; };
    window.addEventListener('beforeunload', before);
    return () => window.removeEventListener('beforeunload', before);
  }, [locked, result, saved]);

  function replaceResult(next) {
    urls.current.forEach(url => URL.revokeObjectURL(url));
    urls.current = [];
    const url = URL.createObjectURL(next.blob || next.rawBlob);
    urls.current.push(url);
    setResult({ ...next, url });
    setSaved(false);
  }

  async function convert(recording) {
    const controller = new AbortController();
    conversion.current = controller;
    setPhase('converting');
    setProgress(0);
    try {
      const blob = await makeMp4(recording.rawBlob || recording.blob, {
        signal: controller.signal,
        onProgress: value => { if (mounted.current) setProgress(Math.round(value * 100)); },
      });
      if (!mounted.current) return;
      replaceResult({ blob, duration: recording.duration, filename: recordingFilename('video/mp4') });
      if (recording.reason === 'limit' || recording.reason === 'encoder') setNotice(recording.reason);
    } catch (error) {
      if (!mounted.current) return;
      replaceResult({ rawBlob: recording.rawBlob || recording.blob, duration: recording.duration });
      setNotice(error?.name === 'AbortError' ? 'conversion-canceled' : 'conversion');
    } finally {
      conversion.current = null;
      if (mounted.current) { setPhase('idle'); setOpen(true); }
    }
  }

  async function start() {
    if (locked || starting.current || !supported || !mime) return;
    starting.current = true;
    setPhase('choosing'); setNotice(''); setProgress(0);
    let stream;
    try {
      const hd = quality === '1080';
      // This call deliberately stays in the user's click activation. The
      // browser must ask the user which screen/tab to share every time.
      stream = await navigator.mediaDevices.getDisplayMedia({
        video: { width: { max: hd ? 1920 : 1280 }, height: { max: hd ? 1080 : 720 }, frameRate: { max: 30 } },
        audio: false, preferCurrentTab: true, selfBrowserSurface: 'include', surfaceSwitching: 'exclude',
      });
      if (!mounted.current) { stream.getTracks().forEach(track => track.stop()); return; }
      const current = new CaptureSession(stream, mime, hd ? 5000000 : 2500000, () => {
        if (!mounted.current) return;
        setBytes(current.bytes);
        setPhase(['stopping', 'stopped'].includes(current.state) ? 'finalizing' : current.state);
      });
      session.current = current;
      current.start();
      setSeconds(0); setBytes(0); setOpen(false);
      const recorded = await current.done;
      if (!mounted.current) return;
      setSeconds(recorded.duration / 1000);
      await convert(recorded);
    } catch (error) {
      stream?.getTracks().forEach(track => track.stop());
      if (mounted.current) {
        setNotice(['NotAllowedError', 'AbortError'].includes(error?.name) ? 'permission' : 'capture');
        setPhase('idle'); setOpen(true);
      }
    } finally { starting.current = false; }
  }

  function save(original = false) {
    const blob = original ? result?.rawBlob : result?.blob;
    if (!blob) return;
    const link = document.createElement('a');
    link.href = result.url;
    link.download = recordingFilename(blob.type);
    document.body.appendChild(link); link.click(); link.remove();
    setSaved(true);
  }
  function togglePause() { if (phase === 'paused') session.current?.resume(); else session.current?.pause(); }
  const messages = {
    permission: t('已取消画面选择，未开始录制。点击开始录制后，选择当前标签页并允许共享。', 'Screen selection was canceled or denied. To record, start again and choose this tab in the browser dialog.'),
    capture: t('未能完成录制。请在桌面 Chrome 或 Edge 中重试，并允许共享当前标签页。', 'Recording could not complete. Retry in desktop Chrome or Edge and allow sharing of this tab.'),
    conversion: t('此环境未能生成 MP4，原始片段仍保留。可重试转换，或下载原始 WebM 后转换；请优先使用新版桌面 Chrome / Edge。', 'MP4 conversion failed in this environment. The original clip is preserved: retry conversion or download the original WebM. A current desktop Chrome or Edge is recommended.'),
    'conversion-canceled': t('已取消 MP4 转换，原始片段仍保留，可以再次转换。', 'MP4 conversion canceled. The original clip is preserved for another attempt.'),
    limit: t('已达到单次 10 分钟或 200 MB 上限，录制已结束。', 'Recording ended at the 10-minute or 200 MB limit.'),
    encoder: t('编码曾中断，已保留收到的视频片段。请预览后保存。', 'Encoding was interrupted. Received footage is preserved; preview it before saving.'),
  };

  return <div className="studio-recorder" ref={shell}>
    <button className={`record-trigger ${active ? 'record-active' : ''}`} onClick={() => setOpen(value => !value)} aria-expanded={open} aria-controls="studio-record-panel" title={t('录制整个演示界面', 'Record the full demo interface')}>
      {active ? <i className={phase === 'paused' ? 'paused' : ''} /> : <Video size={16} />}
      <span>{active ? clock(seconds) : t('录屏', 'Record')}</span>
      {!active && locked && <LoaderCircle className="spin" size={12} />}
    </button>
    {active && <div className="record-inline-controls">
      <button onClick={togglePause} title={phase === 'paused' ? t('继续录制', 'Resume recording') : t('暂停录制', 'Pause recording')} aria-label={phase === 'paused' ? t('继续录制', 'Resume recording') : t('暂停录制', 'Pause recording')}>{phase === 'paused' ? <Play size={14} /> : <Pause size={14} />}</button>
      <button onClick={() => session.current?.stop()} className="record-stop" title={t('结束录制', 'Stop recording')} aria-label={t('结束录制', 'Stop recording')}><Square size={13} /></button>
    </div>}
    {open && <section id="studio-record-panel" className="record-panel" aria-label={t('界面录屏', 'Screen recording')}>
      <div className="record-panel-heading"><h2>{t('界面录屏', 'Screen recording')}</h2><button className="icon-button" onClick={() => setOpen(false)} aria-label={t('收起录屏面板', 'Close recording panel')}><X size={16} /></button></div>
      <p>{t('选择当前标签页，录制整个可见界面。可先点击右上角全屏，再开始录制；不采集声音；暂停录屏不会暂停仿真。', 'Choose this tab to record its entire visible interface. You can enter full screen first. No audio is captured. Recording pause does not pause the simulation.')}</p>
      <div className="record-settings"><label>{t('画面质量', 'Quality')}<select disabled={locked} value={quality} onChange={event => setQuality(event.target.value)}><option value="1080">1080p · 30 FPS</option><option value="720">720p · 30 FPS</option></select></label><span>MP4<small>≤ 30 FPS</small></span></div>
      {(!supported || !mime) && <p className="record-notice">{t('当前浏览器不支持屏幕录制，请用桌面 Chrome 或 Edge 打开此网址。', 'Screen recording is unavailable here. Open this URL in desktop Chrome or Edge.')}</p>}
      {!!mime && !mime.startsWith('video/mp4') && <p className="record-small">{t('此浏览器先录制 WebM，结束后在本机转换为 MP4。', 'This browser records WebM first, then converts it locally to MP4.')}</p>}
      <div className="record-buttons">
        {!active ? <button className="primary" disabled={locked || !supported || !mime} onClick={start}><Circle size={13} />{phase === 'choosing' ? t('等待选择画面…', 'Choose a screen…') : phase === 'finalizing' ? t('正在整理视频…', 'Finalizing…') : phase === 'converting' ? t(`正在生成 MP4 · ${progress}%`, `Creating MP4 · ${progress}%`) : t('开始录制', 'Start recording')}</button> : <><button onClick={togglePause}>{phase === 'paused' ? <Play size={14} /> : <Pause size={14} />}{phase === 'paused' ? t('继续', 'Resume') : t('暂停', 'Pause')}</button><button className="record-stop" onClick={() => session.current?.stop()}><Square size={13} />{t('结束录制', 'Stop recording')}</button></>}
        {phase === 'converting' && <button onClick={() => conversion.current?.abort()}>{t('取消转换', 'Cancel conversion')}</button>}
      </div>
      {active && <div className="record-state"><span>{phase === 'paused' ? t('已暂停', 'Paused') : 'REC'} · {clock(seconds)}</span><span>{(bytes / 1048576).toFixed(1)} MB</span></div>}
      <p className="record-small">{t('视频仅保留在本机，不上传。单段最多 10 分钟 / 200 MB。结束后点击“保存 MP4”。', 'Video stays on your device. Up to 10 minutes / 200 MB per clip. After stopping, click Save MP4.')}</p>
      {!!notice && <p role="status" className="record-notice">{messages[notice]}</p>}
      {!!result && !locked && <div className="record-result"><video src={result.url} controls playsInline preload="metadata" aria-label={t('录屏预览', 'Recording preview')} /><div className="record-result-meta"><span>{clock(result.duration / 1000)}</span><span>{((result.blob || result.rawBlob).size / 1048576).toFixed(1)} MB</span><span>{result.blob ? 'MP4' : 'WebM'}</span></div><div className="record-buttons">{result.blob ? <button className="primary" onClick={() => save()}><Download size={14} />{t('保存 MP4', 'Save MP4')}</button> : <><button onClick={() => { setNotice(''); convert(result); }}><RotateCcw size={14} />{t('重试 MP4 转换', 'Retry MP4')}</button><button onClick={() => save(true)}><Download size={14} />{t('原始 WebM', 'Original WebM')}</button></>}</div>{saved && <p className="record-saved" role="status">{t('已发起下载，请在浏览器下载列表中确认。', 'Download requested. Check your browser downloads.')}</p>}</div>}
    </section>}
  </div>;
}
