import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { ArrowLeft, ArrowUpRight, ArrowRight, LockKeyhole, LoaderCircle, Check, Eye, EyeOff, Mail, Network } from 'lucide-react';
import { ACCESS_CONFIG, PASSWORD_MAX_LENGTH, verifyAccessPassword } from './access.js';
import ContactPanel from './ContactPanel.jsx';
import './access.css';

const linkedIn = 'https://www.linkedin.com/in/binquan-guo-754078371/';
const requestEmail = 'mailto:13468897661@163.com?subject=CARELab%20Carbon%20Studio%20%E2%80%94%20access%20request';

export default function AccessGate({ children }) {
  const [phase, setPhase] = useState(ACCESS_CONFIG.enabled ? 'locked' : 'open');
  const [lang, setLang] = useState(() => { try { return localStorage.getItem('carelab-carbon-studio-lang') === 'en' ? 'en' : 'zh'; } catch { return 'zh'; } });
  const [password, setPassword] = useState(''), [showPassword, setShowPassword] = useState(false);
  const [checking, setChecking] = useState(false), [message, setMessage] = useState(''), [remaining, setRemaining] = useState(0);
  const dialog = useRef(null), panel = useRef(null), input = useRef(null), attempts = useRef(0), cooldown = useRef(0), submitting = useRef(false), live = useRef(true);
  const locked = phase !== 'open', zh = lang === 'zh', t = (en, cn) => zh ? cn : en;

  useLayoutEffect(() => {
    if (!locked || !dialog.current) return;
    if (!dialog.current.open) dialog.current.showModal();
    panel.current?.focus({ preventScroll: true });
  }, [locked]);
  useEffect(() => { live.current = true; return () => { live.current = false; }; }, []);
  useEffect(() => {
    if (!remaining) return;
    const interval = setInterval(() => setRemaining(Math.max(0, Math.ceil((cooldown.current - Date.now()) / 1000))), 250);
    return () => clearInterval(interval);
  }, [remaining > 0]);
  useEffect(() => {
    if (phase !== 'opening') return;
    const delay = matchMedia('(prefers-reduced-motion: reduce)').matches ? 80 : 850;
    const timer = setTimeout(() => {
      dialog.current?.close();
      setPhase('open');
      requestAnimationFrame(() => document.querySelector('.home-return')?.focus({ preventScroll: true }));
    }, delay);
    return () => clearTimeout(timer);
  }, [phase]);

  async function unlock(event) {
    event.preventDefault();
    if (submitting.current || phase !== 'locked' || cooldown.current > Date.now()) return;
    if (!password) { setMessage('empty'); input.current?.focus(); return; }
    submitting.current = true; setChecking(true); setMessage('');
    try {
      const correct = await verifyAccessPassword(password);
      if (!live.current) return;
      setPassword(''); setShowPassword(false);
      if (correct) {
        attempts.current = 0;
        setPhase('opening');
      } else {
        attempts.current += 1;
        setMessage('wrong');
        if (attempts.current % 5 === 0) { cooldown.current = Date.now() + 8000; setRemaining(8); }
        input.current?.focus();
      }
    } catch {
      if (live.current) { setPassword(''); setMessage('unavailable'); }
    } finally {
      submitting.current = false;
      if (live.current) setChecking(false);
    }
  }

  return <>
    <div className="access-content" inert={locked ? true : undefined} aria-hidden={locked ? true : undefined}>
      {React.cloneElement(children, { previewLocked: locked, previewLanguage: lang })}
    </div>
    {locked && <dialog ref={dialog} className={`access-gate ${phase === 'opening' ? 'is-opening' : ''}`} aria-labelledby="access-title" aria-describedby="access-description" onCancel={event => event.preventDefault()}>
      <div className="access-curtain access-curtain-left" aria-hidden="true"/>
      <div className="access-curtain access-curtain-right" aria-hidden="true"/>
      <div className="access-panel" ref={panel} tabIndex={-1}>
        <div className="access-topline"><span><Network size={16} aria-hidden="true"/> CARELab</span><button className="access-language" type="button" onClick={() => setLang(zh ? 'en' : 'zh')} aria-label={zh ? 'Switch to English' : '切换为中文'}>{zh ? 'EN' : '中文'}</button></div>
        <div className="access-lock" aria-hidden="true">{phase === 'opening' ? <Check size={23}/> : <LockKeyhole size={23}/>}</div>
        <p className="access-eyebrow">CARBON STUDIO</p>
        <h1 id="access-title">{t('Research preview', '研究演示')}</h1>
        <p id="access-description">{t('A work in progress. Enter your access password to explore.', '系统完善中，输入访问密码即可体验。')}</p>
        <form onSubmit={unlock} className="access-form">
          <label htmlFor="access-password">{t('Access password', '访问密码')}</label>
          <div className="access-input-wrap"><input id="access-password" ref={input} type={showPassword ? 'text' : 'password'} value={password} onChange={event => { setPassword(event.target.value); setMessage(''); }} autoComplete="off" autoCapitalize="none" spellCheck={false} maxLength={PASSWORD_MAX_LENGTH} placeholder={t('Enter password', '请输入密码')} aria-describedby="access-feedback" aria-invalid={message === 'wrong'} readOnly={checking || phase === 'opening'} disabled={remaining > 0}/><button type="button" className="access-eye" onClick={() => setShowPassword(value => !value)} aria-label={showPassword ? t('Hide password', '隐藏密码') : t('Show password', '显示密码')} aria-pressed={showPassword} disabled={phase === 'opening'}>{showPassword ? <EyeOff size={17}/> : <Eye size={17}/>}</button></div>
          <button className="access-unlock" type="submit" disabled={checking || remaining > 0 || phase === 'opening'}>{checking ? <LoaderCircle className="access-spinner" size={17}/> : phase === 'opening' ? <Check size={17}/> : <ArrowRight size={17}/>}<span>{checking ? t('Checking…', '正在验证…') : phase === 'opening' ? t('Welcome', '欢迎体验') : remaining > 0 ? t(`Try again in ${remaining}s`, `${remaining} 秒后可重试`) : t('Enter studio', '进入演示')}</span></button>
          <p id="access-feedback" className="access-feedback" role="status" aria-live="polite">{message === 'wrong' ? t('That password does not match. Please try again.', '密码不正确，请重试。') : message === 'empty' ? t('Please enter your access password.', '请输入访问密码。') : message === 'unavailable' ? t('Unable to verify. Please reload using a current browser over HTTPS or localhost.', '暂时无法验证，请使用新版浏览器，通过 HTTPS 或 localhost 重新打开。') : '\u00a0'}</p>
        </form>
        <div className="access-divider"><span>{t('Connect with Binquan Guo', '与郭斌全交流')}</span></div>
        <nav className="access-contacts" aria-label={t('Contact and access', '联系与访问')}><ContactPanel lang={lang} compact idPrefix="access"/><a href={linkedIn} target="_blank" rel="noopener noreferrer">LinkedIn <ArrowUpRight size={13}/></a><a href={requestEmail}><Mail size={13}/>{t('Request access', '申请访问')}</a></nav>
        <a className="access-home" href="https://wilixx.github.io/"><ArrowLeft size={13}/>{t('Back to homepage', '返回个人主页')}</a>
        <p className="access-session-note">{t('Refreshing this page locks the preview again.', '刷新页面后需重新输入密码。')}</p>
      </div>
    </dialog>}
  </>;
}
