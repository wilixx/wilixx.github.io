import React, {useEffect, useMemo, useRef, useState} from 'react';
import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {ledgerAt} from './engine.js';
import {layoutDag, serverLayout} from './scene-layout.js';
import './scene.css';

export const TASK_COLORS = ['#5fc9ba', '#73a7ff', '#e1b969', '#b298e9', '#e48d9a', '#73c2df', '#b1c47a', '#de9a6f'];
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
const number = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
const carbonText = value => number(value) === 0 ? '0.000' : Math.abs(value) < .001 ? Number(value).toPrecision(2) : Number(value).toFixed(value >= 100 ? 1 : 3);
const tuText = value => Number(number(value).toFixed(2)).toString();
const vector = point => new THREE.Vector3(point.x, point.y, point.z);
const taskColor = (dag, id) => TASK_COLORS[Math.max(0, (dag.nodes || []).findIndex(node => String(node.id) === String(id))) % TASK_COLORS.length];
const taskSelection = (node, row) => ({type: 'task', id: node.id, duration: node.duration, resource: row?.resource ?? null, start: row?.start ?? null, end: row?.end ?? null});

function Fallback({dag, result, ledger, lang, onSelect}) {
  const zh = lang === 'zh';
  const tasks = new Map((result?.tasks || []).map(task => [String(task.id), task]));
  return <div className="carbon-scene-fallback">
    <p>{zh ? '当前设备无法开启 3D，实时能耗与排放仍可查看。' : '3D is unavailable on this device. Live energy and carbon remain available.'}</p>
    <div className="carbon-fallback-resources">
      {(ledger?.servers || []).map(server => <button key={server.resource} onClick={() => onSelect?.({type: 'server', resource: server.resource})}>
        <strong>VM {server.resource + 1}</strong><span>{carbonText(server.carbonG)} gCO₂e</span>
        <small>{number(server.powerW).toFixed(0)} W · {server.activeTask != null ? `T${server.activeTask}` : ledger?.finished ? zh ? '已释放' : 'Released' : zh ? '空闲' : 'Idle'}</small>
      </button>)}
      <div><strong>{zh ? '网络' : 'Network'}</strong><span>{carbonText(ledger?.network?.carbonG)} gCO₂e</span><small>{number(ledger?.network?.powerW).toFixed(0)} W</small></div>
    </div>
    <div className="carbon-fallback-tasks">{(dag?.nodes || []).map(node => {
      const task = tasks.get(String(node.id));
      const state = task && ledger?.time >= task.end ? 'done' : task && ledger?.time >= task.start ? 'running' : 'waiting';
      return <button key={node.id} data-state={state} style={{'--task-color': taskColor(dag, node.id)}} onClick={() => onSelect?.(taskSelection(node, task))}>T{node.id}<small>{task ? `${tuText(task.start)}–${tuText(task.end)} tu · VM ${task.resource + 1}` : `${tuText(node.duration)} tu`}</small></button>;
    })}</div>
  </div>;
}

/** One independent method viewport. All accounting comes from the shared engine. */
export default function Scene({dag, result, config, time = 0, playing = false, lang = 'zh', showAssignments = true, smoke = true, resetKey = 0, onSelect, comparisonEndTime}) {
  const host = useRef(null);
  const controlsApi = useRef(null);
  const [bad, setBad] = useState(false);
  const [ready, setReady] = useState(false);
  const ledger = useMemo(() => result ? ledgerAt(dag, result, config, time) : null, [dag, result, config, time]);
  const live = useRef(null);
  live.current = {dag, result, config, time, playing, lang, showAssignments, smoke, onSelect, ledger, comparisonEndTime};
  const servers = clamp(Math.floor(number(config?.servers, dag?.resources?.servers || 1)), 1, 8);
  const channels = clamp(Math.floor(number(config?.channels, dag?.resources?.channels || 1)), 1, 16);

  useEffect(() => {
    const element = host.current;
    if (!element || !dag) return;
    setBad(false);
    setReady(false);
    let renderer;
    try {
      renderer = new THREE.WebGLRenderer({antialias: true, alpha: false, powerPreference: 'low-power'});
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
      renderer.setClearColor('#060e19');
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      element.appendChild(renderer.domElement);
    } catch {
      setBad(true);
      return;
    }
    const canvas = renderer.domElement;
    canvas.setAttribute('aria-label', lang === 'zh' ? '任务 DAG、虚拟机和网络的交互式 3D 场景' : 'Interactive 3D task DAG, virtual machines and network');
    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog('#060e19', 29, 54);
    const camera = new THREE.PerspectiveCamera(39, 1, .1, 100);
    const control = new OrbitControls(camera, canvas);
    control.enableDamping = true;
    control.dampingFactor = .09;
    control.enablePan = true;
    control.screenSpacePanning = true;
    control.minPolarAngle = .36;
    control.maxPolarAngle = Math.PI * .52;
    control.rotateSpeed = .55;
    control.zoomSpeed = .7;
    control.target.set(0, 4.1, 0);
    const resetCamera = () => {
      const aspect = Math.max(.45, element.clientWidth / Math.max(1, element.clientHeight));
      const distance = Math.max(20, 20 / aspect);
      control.target.set(0, 4.1, 0);
      camera.position.set(.25, 4.1 + distance * .21, distance);
      control.minDistance = 8;
      control.maxDistance = Math.max(54, distance * 2.5);
      control.update();
    };
    controlsApi.current = {
      reset: resetCamera,
      zoom: factor => { camera.position.sub(control.target).multiplyScalar(factor).add(control.target); control.update(); },
    };
    scene.add(new THREE.HemisphereLight('#c7e5ff', '#101b31', 2.5));
    const keyLight = new THREE.DirectionalLight('#adcbff', 3.1);
    keyLight.position.set(-5, 12, 10);
    scene.add(keyLight);
    const tealLight = new THREE.PointLight('#53ecc0', 18, 18);
    tealLight.position.set(0, 2.8, 1);
    scene.add(tealLight);
    const plane = new THREE.Mesh(new THREE.PlaneGeometry(14.6, 8.6), new THREE.MeshStandardMaterial({color: '#0b1c2c', metalness: .18, roughness: .85, transparent: true, opacity: .85}));
    plane.rotation.x = -Math.PI / 2;
    plane.position.y = -.12;
    scene.add(plane);
    const grid = new THREE.GridHelper(14, 14, '#214957', '#142b3c');
    grid.position.y = -.1;
    grid.material.transparent = true;
    grid.material.opacity = .56;
    scene.add(grid);
    const platformEdge = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(14.6, .12, 8.6)), new THREE.LineBasicMaterial({color: '#32667a', transparent: true, opacity: .65}));
    platformEdge.position.y = -.17;
    scene.add(platformEdge);

    const overlay = document.createElement('div');
    overlay.className = 'carbon-world-overlay';
    element.appendChild(overlay);
    const labels = [];
    const selectable = [];
    const addLabel = (className, point, html, select) => {
      const label = document.createElement(select ? 'button' : 'div');
      label.className = `carbon-world-label ${className}`;
      label.innerHTML = html;
      if (select) {
        label.type = 'button';
        label.addEventListener('click', () => live.current.onSelect?.(select));
      }
      overlay.appendChild(label);
      const data = {element: label, point, width: 0, height: 0};
      labels.push(data);
      return data;
    };
    const positions = layoutDag(dag);
    const taskRows = new Map((result?.tasks || []).map(task => [String(task.id), task]));
    const flowRows = new Map((result?.flows || []).map(flow => [`${flow.source}:${flow.target}`, flow]));
    const hostPositions = serverLayout(servers);
    const taskObjects = [];
    const taskById = new Map();
    const taskGeometry = new THREE.OctahedronGeometry(.26, 0);
    const taskRingGeometry = new THREE.TorusGeometry(.35, .018, 5, 24);
    const assignmentGroup = new THREE.Group();
    scene.add(assignmentGroup);
    const assignments = [];
    const edgeObjects = [];
    for (const [index, node] of (dag.nodes || []).entries()) {
      const position = positions.get(String(node.id));
      if (!position) continue;
      const color = TASK_COLORS[index % TASK_COLORS.length];
      const selection = taskSelection(node, taskRows.get(String(node.id)));
      const mesh = new THREE.Mesh(taskGeometry, new THREE.MeshStandardMaterial({color, emissive: color, emissiveIntensity: .15, roughness: .55, metalness: .25}));
      mesh.position.copy(vector(position));
      mesh.userData.selection = selection;
      scene.add(mesh);
      selectable.push(mesh);
      const ring = new THREE.Mesh(taskRingGeometry, new THREE.MeshBasicMaterial({color, transparent: true, opacity: .25}));
      ring.position.copy(mesh.position);
      scene.add(ring);
      const label = addLabel('carbon-task-label', mesh.position.clone().add(new THREE.Vector3(0, .13, .05)), '<strong></strong><small></small>', selection);
      label.element.style.setProperty('--task-color', color);
      label.element.dataset.task = String(node.id);
      label.element.querySelector('strong').textContent = `T${node.id}`;
      label.element.querySelector('small').textContent = `${tuText(node.duration)} tu`;
      const object = {node, mesh, ring, label, color, row: taskRows.get(String(node.id)), state: ''};
      taskObjects.push(object);
      taskById.set(String(node.id), object);
      const server = hostPositions[object.row?.resource];
      if (server) {
        const points = [mesh.position.clone().add(new THREE.Vector3(0, -.3, 0)), new THREE.Vector3(server.x, 1.05, server.z)];
        const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints(points), new THREE.LineDashedMaterial({color, transparent: true, opacity: .12, dashSize: .1, gapSize: .13, depthWrite: false}));
        line.computeLineDistances();
        assignmentGroup.add(line);
        assignments.push({line, task: object});
      }
    }
    for (const [edgeIndex, edge] of (dag.edges || []).entries()) {
      const from = taskById.get(String(edge.source));
      const to = taskById.get(String(edge.target));
      if (!from || !to) continue;
      const start = from.mesh.position.clone();
      const end = to.mesh.position.clone();
      const direction = end.clone().sub(start).normalize();
      start.addScaledVector(direction, .3);
      end.addScaledVector(direction, -.38);
      const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints([start, end]), new THREE.LineBasicMaterial({color: '#6e91af', transparent: true, opacity: .35, depthWrite: false}));
      const arrow = new THREE.Mesh(new THREE.ConeGeometry(.052, .16, 5), new THREE.MeshBasicMaterial({color: '#6e91af', transparent: true, opacity: .65}));
      arrow.position.copy(end);
      arrow.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction);
      scene.add(line, arrow);
      let label = null;
      if ((dag.edges || []).length <= 16) {
        const outgoing = dag.edges.filter(candidate => String(candidate.source) === String(edge.source)).length;
        const incoming = dag.edges.filter(candidate => String(candidate.target) === String(edge.target)).length;
        const fraction = (outgoing > incoming ? .6 : incoming > outgoing ? .4 : .5) + (edgeIndex % 3 - 1) * .01;
        const midpoint = from.mesh.position.clone().lerp(to.mesh.position, fraction);
        midpoint.y += .13;
        midpoint.z += .06;
        label = addLabel('carbon-edge-label', midpoint, '<span></span>');
        label.element.querySelector('span').textContent = `${tuText(edge.duration)} tu`;
        label.element.dataset.edge = `${edge.source}:${edge.target}`;
        label.element.title = `T${edge.source} → T${edge.target} · ${tuText(edge.duration)} tu`;
        label.element.setAttribute('aria-label', label.element.title);
      }
      edgeObjects.push({edge, line, arrow, label});
    }

    const hub = new THREE.Group();
    hub.position.set(0, .55, 0);
    const hubBody = new THREE.Mesh(new THREE.CylinderGeometry(.64, .72, .35, 6), new THREE.MeshStandardMaterial({color: '#153849', metalness: .65, roughness: .3, emissive: '#2b6080', emissiveIntensity: .3}));
    const hubRing = new THREE.Mesh(new THREE.TorusGeometry(.84, .035, 6, 40), new THREE.MeshBasicMaterial({color: '#73a7ff', transparent: true, opacity: .6}));
    hubRing.rotation.x = Math.PI / 2;
    hub.add(hubBody, hubRing);
    scene.add(hub);
    const hubLabel = addLabel('carbon-hub-label', new THREE.Vector3(2.3, 1.7, .2), '<strong></strong><span></span><small></small>');
    const hubBar = new THREE.Mesh(new THREE.BoxGeometry(.15, 1, .15), new THREE.MeshBasicMaterial({color: '#73a7ff', transparent: true, opacity: .8}));
    hubBar.position.set(.96, .2, 0);
    scene.add(hubBar);
    const hostObjects = [];
    const spokes = [];
    const bodyGeometry = new THREE.BoxGeometry(1.05, .88, .85);
    const slitGeometry = new THREE.BoxGeometry(.7, .045, .025);
    const barGeometry = new THREE.BoxGeometry(.14, 1, .14);
    hostPositions.forEach((position, resource) => {
      const body = new THREE.Mesh(bodyGeometry, new THREE.MeshStandardMaterial({color: '#203c52', metalness: .45, roughness: .48, emissive: '#132432', emissiveIntensity: .4}));
      body.position.set(position.x, .45, position.z);
      body.userData.selection = {type: 'server', resource};
      scene.add(body);
      selectable.push(body);
      const slits = [];
      for (let i = 0; i < 4; i++) {
        const slit = new THREE.Mesh(slitGeometry, new THREE.MeshBasicMaterial({color: '#2e6270', transparent: true, opacity: .8}));
        slit.position.set(position.x, .2 + i * .15, position.z + .438);
        scene.add(slit);
        slits.push(slit);
      }
      const top = new THREE.Mesh(new THREE.BoxGeometry(.85, .025, .64), new THREE.MeshBasicMaterial({color: '#17374b'}));
      top.position.set(position.x, .903, position.z);
      scene.add(top);
      const bar = new THREE.Mesh(barGeometry, new THREE.MeshBasicMaterial({color: '#e1b969', transparent: true, opacity: .92}));
      bar.position.set(position.x + .72, 0, position.z);
      scene.add(bar);
      const label = addLabel('carbon-server-label', new THREE.Vector3(position.x, .0, position.z + .72), '<strong></strong><span></span><small></small>', {type: 'server', resource});
      label.element.dataset.resource = String(resource);
      label.element.querySelector('strong').textContent = `VM ${resource + 1}`;
      hostObjects.push({resource, position, body, slits, bar, label});
      for (let channel = 0; channel < channels; channel++) {
        const offset = (channel - (channels - 1) / 2) * Math.min(.08, .45 / channels);
        const direction = new THREE.Vector3(-position.z, 0, position.x).normalize().multiplyScalar(offset);
        const start = new THREE.Vector3(position.x, .32, position.z).add(direction);
        const end = new THREE.Vector3(0, .56, 0).add(direction);
        const material = new THREE.LineBasicMaterial({color: TASK_COLORS[channel % TASK_COLORS.length], transparent: true, opacity: .12, depthWrite: false});
        const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints([start, end]), material);
        scene.add(line);
        spokes.push({resource, channel, line, start, end});
      }
    });
    const packetGeometry = new THREE.SphereGeometry(.055, 6, 4);
    const packets = Array.from({length: channels * 3}, (_, index) => {
      const mesh = new THREE.Mesh(packetGeometry, new THREE.MeshBasicMaterial({color: TASK_COLORS[Math.floor(index / 3) % TASK_COLORS.length]}));
      mesh.visible = false;
      scene.add(mesh);
      return mesh;
    });

    const spriteCanvas = document.createElement('canvas');
    spriteCanvas.width = spriteCanvas.height = 32;
    const context = spriteCanvas.getContext('2d');
    const gradient = context.createRadialGradient(16, 16, 0, 16, 16, 16);
    gradient.addColorStop(0, 'rgba(207,231,236,.85)');
    gradient.addColorStop(.3, 'rgba(174,200,216,.5)');
    gradient.addColorStop(1, 'rgba(152,176,199,0)');
    context.fillStyle = gradient;
    context.fillRect(0, 0, 32, 32);
    const sprite = new THREE.CanvasTexture(spriteCanvas);
    const plumes = [...hostPositions.map(position => ({...position, y: .98})), {x: 0, z: 0, y: .95}].map((position, index) => {
      const data = new Float32Array(42 * 3);
      const geometry = new THREE.BufferGeometry();
      geometry.setAttribute('position', new THREE.BufferAttribute(data, 3).setUsage(THREE.DynamicDrawUsage));
      const material = new THREE.PointsMaterial({map: sprite, color: '#b8ccd4', size: .58, transparent: true, opacity: .23, depthWrite: false, sizeAttenuation: true});
      const points = new THREE.Points(geometry, material);
      points.frustumCulled = false;
      scene.add(points);
      return {points, data, position, index};
    });

    let pointerDown = null;
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    const down = event => { if (event.button === 0) pointerDown = [event.clientX, event.clientY]; };
    const up = event => {
      if (!pointerDown || event.button !== 0 || Math.hypot(event.clientX - pointerDown[0], event.clientY - pointerDown[1]) > 5) { pointerDown = null; return; }
      pointerDown = null;
      const rect = canvas.getBoundingClientRect();
      pointer.set((event.clientX - rect.left) / rect.width * 2 - 1, -(event.clientY - rect.top) / rect.height * 2 + 1);
      raycaster.setFromCamera(pointer, camera);
      const hit = raycaster.intersectObjects(selectable, false)[0];
      if (hit) live.current.onSelect?.(hit.object.userData.selection);
    };
    const cancelPointer = () => { pointerDown = null; };
    const lostContext = event => { event.preventDefault(); setBad(true); };
    canvas.addEventListener('pointerdown', down);
    canvas.addEventListener('pointerup', up);
    canvas.addEventListener('pointercancel', cancelPointer);
    canvas.addEventListener('webglcontextlost', lostContext);

    let width = 0;
    let height = 0;
    let firstResize = true;
    let resized = true;
    let previousFitScale = 1;
    const resize = () => {
      width = element.clientWidth;
      height = element.clientHeight;
      if (!width || !height) return;
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      resized = true;
      const fitScale = Math.max(1, 1 / camera.aspect);
      if (firstResize) { resetCamera(); firstResize = false; }
      else if (fitScale !== previousFitScale) camera.position.sub(control.target).multiplyScalar(fitScale / previousFitScale).add(control.target);
      previousFitScale = fitScale;
      labels.forEach(label => { label.width = label.element.offsetWidth; label.height = label.element.offsetHeight; });
    };
    const observer = new ResizeObserver(resize);
    observer.observe(element);
    resize();
    let frame;
    let previousTime = performance.now();
    let animationTime = .8;
    let lastLedger = null;
    let lastLanguage = null;
    let lastShow = null;
    let lastSmoke = null;
    let lastHorizon = null;
    const projected = new THREE.Vector3();
    const render = now => {
      frame = requestAnimationFrame(render);
      if (renderer.getContext().isContextLost()) return;
      const current = live.current;
      const dt = Math.min(.05, Math.max(0, (now - previousTime) / 1000));
      previousTime = now;
      if (current.playing) animationTime += dt;
      const cameraChanged = control.update();
      const accounting = current.ledger;
      const valuesChanged = accounting !== lastLedger || current.lang !== lastLanguage || current.showAssignments !== lastShow || current.comparisonEndTime !== lastHorizon;
      if (!current.playing && !cameraChanged && !resized && !valuesChanged && current.smoke === lastSmoke) return;
      lastSmoke = current.smoke;
      resized = false;
      camera.updateMatrixWorld();
      const elapsed = number(accounting?.time, Math.min(number(current.time), number(current.result?.completion_time)));
      const endTime = number(current.result?.completion_time);
      const finished = accounting?.finished ?? elapsed >= endTime;
      const activeFlows = finished ? [] : accounting?.network?.activeFlows || [];
      assignmentGroup.visible = current.showAssignments;
      if (valuesChanged) {
        lastLedger = accounting;
        lastLanguage = current.lang;
        lastShow = current.showAssignments;
        lastHorizon = current.comparisonEndTime;
        const zh = current.lang === 'zh';
        canvas.setAttribute('aria-label', zh ? '任务 DAG、虚拟机和网络的交互式 3D 场景' : 'Interactive 3D task DAG, virtual machines and network');
        const activeFlowKeys = new Set(activeFlows.map(flow => `${flow.source}:${flow.target}`));
        taskObjects.forEach(object => {
          const {row, node, mesh, ring, label, color} = object;
          const parents = (dag.edges || []).filter(edge => String(edge.target) === String(node.id));
          const parentsDone = parents.every(edge => {
            const parent = taskRows.get(String(edge.source));
            const transfer = flowRows.get(`${edge.source}:${edge.target}`);
            return parent && parent.end <= elapsed && (!transfer || transfer.end <= elapsed);
          });
          const state = row && elapsed >= row.end ? 'done' : row && elapsed >= row.start && elapsed < row.end ? 'running' : parentsDone ? 'ready' : 'waiting';
          object.state = state;
          mesh.material.color.set(state === 'waiting' ? '#34495f' : color);
          mesh.material.emissive.set(color);
          mesh.material.emissiveIntensity = state === 'running' ? .72 : state === 'done' ? .25 : .07;
          ring.material.opacity = state === 'running' ? .9 : state === 'done' ? .6 : .2;
          label.element.dataset.state = state;
          label.element.title = `T${node.id} · ${tuText(node.duration)} tu · ${zh ? {waiting: '等待前序', ready: '就绪', running: '运行中', done: '完成'}[state] : state}${row ? ` · VM ${row.resource + 1} · ${tuText(row.start)}–${tuText(row.end)} tu` : ''}`;
          label.element.setAttribute('aria-label', label.element.title);
        });
        assignments.forEach(({line, task}) => {
          line.material.opacity = task.state === 'running' ? .6 : task.state === 'done' ? .09 : .11;
          line.material.dashSize = task.state === 'running' ? .17 : .1;
        });
        edgeObjects.forEach(({edge, line, arrow, label}) => {
          const active = activeFlowKeys.has(`${edge.source}:${edge.target}`);
          const color = active ? '#73a7ff' : '#6e91af';
          line.material.color.set(color);
          arrow.material.color.set(color);
          line.material.opacity = active ? .95 : .3;
          if (label) label.element.dataset.state = active ? 'active' : 'idle';
        });
        const horizon = Math.max(endTime, number(current.comparisonEndTime, endTime), .1);
        const factor = number(current.config?.tuSeconds, 1) * number(current.config?.pue, 1) * number(current.config?.ci, 0) / 3600000;
        const ceiling = Math.max(.00000001, Math.max(number(current.config?.busyW), number(current.config?.idleW), number(current.config?.networkW)) * horizon * factor);
        hostObjects.forEach(object => {
          const state = accounting?.servers?.find(server => server.resource === object.resource);
          const busy = state?.activeTask != null && !finished;
          const color = busy ? taskColor(dag, state.activeTask) : '#294c62';
          object.body.material.color.set(busy ? color : finished ? '#203044' : '#203c52');
          object.body.material.emissive.set(color);
          object.body.material.emissiveIntensity = busy ? .3 : .04;
          object.slits.forEach(slit => { slit.material.color.set(busy ? color : '#396070'); slit.material.opacity = finished ? .35 : busy ? 1 : .6; });
          const barHeight = clamp(number(state?.carbonG) / ceiling, 0, 1) * 1.75;
          object.bar.visible = barHeight > .002;
          object.bar.scale.y = Math.max(.002, barHeight);
          object.bar.position.y = barHeight / 2;
          object.label.element.dataset.state = busy ? 'running' : finished ? 'released' : 'idle';
          object.label.element.style.setProperty('--task-color', color);
          object.label.element.querySelector('span').textContent = `${carbonText(state?.carbonG)} gCO₂e`;
          object.label.element.querySelector('small').textContent = `${number(state?.powerW).toFixed(0)} W · ${busy ? `T${state.activeTask}` : finished ? zh ? '已释放' : 'Released' : zh ? '空闲' : 'Idle'}`;
          object.label.element.title = `VM ${object.resource + 1} · ${carbonText(state?.carbonG)} gCO₂e · ${number(state?.energyJ).toFixed(1)} J`;
        });
        hubLabel.element.querySelector('strong').textContent = zh ? `网络 · ${channels} 通道` : `Network · ${channels} ch`;
        hubLabel.element.querySelector('span').textContent = `${carbonText(accounting?.network?.carbonG)} gCO₂e`;
        hubLabel.element.querySelector('small').textContent = `${number(accounting?.network?.powerW).toFixed(0)} W · ${finished ? zh ? '已释放' : 'Released' : activeFlows.length ? zh ? `${activeFlows.length} 传输` : `${activeFlows.length} flows` : zh ? '已预留' : 'Reserved'}`;
        const networkBarHeight = clamp(number(accounting?.network?.carbonG) / ceiling, 0, 1) * 1.75;
        hubBar.visible = networkBarHeight > .002;
        hubBar.scale.y = Math.max(.002, networkBarHeight);
        hubBar.position.y = networkBarHeight / 2;
        hubRing.material.opacity = finished ? .2 : activeFlows.length ? 1 : .45;
        spokes.forEach(spoke => {
          const active = activeFlows.some(flow => flow.resource === spoke.channel && [taskRows.get(String(flow.source))?.resource, taskRows.get(String(flow.target))?.resource].includes(spoke.resource));
          spoke.line.material.opacity = active ? .85 : .11;
        });
        labels.forEach(label => { label.width = label.element.offsetWidth; label.height = label.element.offsetHeight; });
      }
      taskObjects.forEach(object => {
        object.ring.quaternion.copy(camera.quaternion);
        if (object.state === 'running') {
          object.mesh.rotation.y = animationTime * .85;
          object.ring.scale.setScalar(1 + Math.sin(animationTime * 4) * .1);
        } else object.ring.scale.setScalar(1);
      });
      packets.forEach((packet, index) => {
        const flow = activeFlows[Math.floor(index / 3)];
        const source = flow && hostPositions[taskRows.get(String(flow.source))?.resource];
        const target = flow && hostPositions[taskRows.get(String(flow.target))?.resource];
        packet.visible = Boolean(flow && source && target);
        if (!packet.visible) return;
        const progress = ((elapsed - flow.start) / Math.max(.0001, flow.end - flow.start) + (index % 3) * .18) % 1;
        const channel = number(flow.resource);
        const sourceSpoke = spokes.find(spoke => spoke.resource === taskRows.get(String(flow.source))?.resource && spoke.channel === channel);
        const targetSpoke = spokes.find(spoke => spoke.resource === taskRows.get(String(flow.target))?.resource && spoke.channel === channel);
        if (!sourceSpoke || !targetSpoke) { packet.visible = false; return; }
        if (progress < .5) packet.position.lerpVectors(sourceSpoke.start, sourceSpoke.end, progress * 2);
        else packet.position.lerpVectors(targetSpoke.end, targetSpoke.start, (progress - .5) * 2);
        packet.position.y += .045;
        packet.material.color.set(TASK_COLORS[channel % TASK_COLORS.length]);
      });
      plumes.forEach(plume => {
        const isNetwork = plume.index === servers;
        const state = accounting?.servers?.find(server => server.resource === plume.index);
        const busy = isNetwork ? activeFlows.length > 0 : state?.activeTask != null;
        plume.points.visible = current.smoke && !finished && (isNetwork ? busy && number(accounting?.network?.powerW) > 0 : number(state?.powerW) > 0);
        if (!plume.points.visible) return;
        const count = busy ? 42 : 13;
        plume.points.geometry.setDrawRange(0, count);
        plume.points.material.opacity = busy ? .32 : .15;
        plume.points.material.size = busy ? .66 : .39;
        for (let index = 0; index < count; index++) {
          const phase = (animationTime * (busy ? .33 : .18) + index / count + plume.index * .117) % 1;
          const angle = index * 2.399 + plume.index;
          const spread = .1 + phase * (busy ? .48 : .23);
          plume.data[index * 3] = plume.position.x + Math.cos(angle) * spread + phase * .25;
          plume.data[index * 3 + 1] = plume.position.y + phase * (busy ? 1.55 : .85);
          plume.data[index * 3 + 2] = plume.position.z + Math.sin(angle) * spread;
        }
        plume.points.geometry.attributes.position.needsUpdate = true;
      });
      const occupied = [];
      labels.forEach(label => {
        projected.copy(label.point).project(camera);
        const visible = projected.z >= -1 && projected.z <= 1 && Math.abs(projected.x) < 1.16 && Math.abs(projected.y) < 1.16;
        label.element.style.visibility = visible ? 'visible' : 'hidden';
        if (!visible) return;
        let x = (projected.x * .5 + .5) * width;
        let y = (-projected.y * .5 + .5) * height;
        const halfWidth = (label.width || 55) / 2;
        const labelHeight = label.height || 28;
        x = clamp(x, halfWidth + 4, Math.max(halfWidth + 4, width - halfWidth - 4));
        // Small vertical nudges preserve readable labels after orbiting the camera.
        for (let attempt = 0; attempt < 4; attempt++) {
          const collision = occupied.some(rect => x + halfWidth > rect.left && x - halfWidth < rect.right && y + labelHeight > rect.top && y < rect.bottom);
          if (!collision) break;
          y += attempt % 2 ? -labelHeight * 2 : labelHeight;
        }
        y = clamp(y, 32, Math.max(32, height - labelHeight - 20));
        occupied.push({left: x - halfWidth, right: x + halfWidth, top: y, bottom: y + labelHeight});
        label.element.style.transform = `translate3d(${Math.round(x)}px,${Math.round(y)}px,0) translateX(-50%)`;
      });
      renderer.render(scene, camera);
    };
    frame = requestAnimationFrame(render);
    setReady(true);
    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
      control.dispose();
      controlsApi.current = null;
      canvas.removeEventListener('pointerdown', down);
      canvas.removeEventListener('pointerup', up);
      canvas.removeEventListener('pointercancel', cancelPointer);
      canvas.removeEventListener('webglcontextlost', lostContext);
      const geometries = new Set();
      const materials = new Set();
      scene.traverse(object => {
        if (object.geometry) geometries.add(object.geometry);
        if (object.material) (Array.isArray(object.material) ? object.material : [object.material]).forEach(material => materials.add(material));
      });
      geometries.forEach(geometry => geometry.dispose());
      materials.forEach(material => material.dispose());
      sprite.dispose();
      renderer.dispose();
      renderer.forceContextLoss();
      canvas.remove();
      overlay.remove();
    };
  }, [dag, result, servers, channels]);

  useEffect(() => { controlsApi.current?.reset(); }, [resetKey]);
  const zh = lang === 'zh';
  return <div className="carbon-scene" data-renderer={bad ? 'fallback' : ready ? 'webgl' : 'loading'}>
    <div className="carbon-scene-stage" ref={host} aria-hidden={bad || undefined} />
    {bad ? <Fallback dag={dag} result={result} ledger={ledger} lang={lang} onSelect={onSelect} /> : <>
      <div className="carbon-scene-key"><span><i />{zh ? '任务 DAG' : 'Task DAG'}</span><small>{zh ? '时长 · tu' : 'Duration · tu'}</small></div>
      <div className="carbon-scene-controls" aria-label={zh ? '3D 视角控制' : '3D camera controls'}>
        <button type="button" onClick={() => controlsApi.current?.zoom(.82)} title={zh ? '放大' : 'Zoom in'} aria-label={zh ? '放大 3D 场景' : 'Zoom in 3D scene'}>＋</button>
        <button type="button" onClick={() => controlsApi.current?.zoom(1.22)} title={zh ? '缩小' : 'Zoom out'} aria-label={zh ? '缩小 3D 场景' : 'Zoom out 3D scene'}>−</button>
        <button type="button" onClick={() => controlsApi.current?.reset()} title={zh ? '重置视角' : 'Reset view'} aria-label={zh ? '重置 3D 视角' : 'Reset 3D view'}>↺</button>
      </div>
      <div className="carbon-scene-caption">{zh ? '拖动旋转 · 滚轮缩放 · 点击查看' : 'Drag to orbit · Scroll to zoom · Click to inspect'}</div>
      <div className="carbon-scene-smoke-note">{zh ? '烟雾表示功率状态' : 'Plumes indicate power state'}</div>
    </>}
  </div>;
}
